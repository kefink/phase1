#!/usr/bin/env python3
"""
Test script to check and demonstrate the school setup functionality.
"""

import os
import sys
import sqlite3
from datetime import datetime

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def check_database_structure():
    """Check the current database structure."""
    print("=== DATABASE STRUCTURE CHECK ===")
    
    try:
        # Connect to the database
        db_path = '../kirima_primary.db'
        if not os.path.exists(db_path):
            print(f"❌ Database not found at: {db_path}")
            return False
            
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Get all tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [table[0] for table in cursor.fetchall()]
        
        print(f"📋 Found {len(tables)} tables:")
        for table in sorted(tables):
            print(f"  - {table}")
        
        # Check school setup related tables
        school_tables = [t for t in tables if 'school' in t.lower()]
        print(f"\n🏫 School-related tables: {school_tables}")
        
        # Check school_setup table specifically
        if 'school_setup' in tables:
            print("\n=== SCHOOL SETUP TABLE ===")
            cursor.execute("PRAGMA table_info(school_setup)")
            columns = cursor.fetchall()
            print("Columns:")
            for col in columns:
                print(f"  - {col[1]} ({col[2]})")
            
            # Get current data
            cursor.execute("SELECT * FROM school_setup LIMIT 1")
            row = cursor.fetchone()
            if row:
                print("\nCurrent data:")
                col_names = [col[1] for col in columns]
                for i, col_name in enumerate(col_names):
                    print(f"  {col_name}: {row[i]}")
            else:
                print("❌ No data in school_setup table")
        else:
            print("❌ school_setup table not found")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Error checking database: {e}")
        return False

def test_school_setup_models():
    """Test the school setup models."""
    print("\n=== TESTING SCHOOL SETUP MODELS ===")
    
    try:
        # Import Flask app and models
        from run import create_app
        from models.school_setup import SchoolSetup, SchoolBranding, SchoolCustomization
        from services.school_config_service import EnhancedSchoolSetupService
        
        # Create app context
        app = create_app('development')
        
        with app.app_context():
            print("✅ App context created successfully")
            
            # Test getting school setup
            setup = SchoolSetup.get_current_setup()
            print(f"📋 School setup retrieved: {setup.school_name}")
            print(f"   Setup completed: {setup.setup_completed}")
            print(f"   Current step: {setup.setup_step}")
            print(f"   Academic year: {setup.current_academic_year}")
            print(f"   Current term: {setup.current_term}")
            
            # Test service methods
            service_setup = EnhancedSchoolSetupService.get_school_setup()
            print(f"🔧 Service setup: {service_setup.school_name}")
            
            progress = EnhancedSchoolSetupService.get_setup_progress()
            print(f"📊 Setup progress: {progress}%")
            
            is_completed = EnhancedSchoolSetupService.is_setup_completed()
            print(f"✅ Setup completed: {is_completed}")
            
            # Test comprehensive info
            comprehensive_info = EnhancedSchoolSetupService.get_comprehensive_school_info()
            print(f"📋 Comprehensive info keys: {list(comprehensive_info.keys())}")
            
        return True
        
    except Exception as e:
        print(f"❌ Error testing models: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_school_config_service():
    """Test the school configuration service."""
    print("\n=== TESTING SCHOOL CONFIG SERVICE ===")
    
    try:
        from run import create_app
        from services.school_config_service import SchoolConfigService
        
        app = create_app('development')
        
        with app.app_context():
            print("✅ Testing SchoolConfigService methods:")
            
            # Test various service methods
            school_name = SchoolConfigService.get_school_name()
            print(f"  School name: {school_name}")
            
            logo_path = SchoolConfigService.get_school_logo_path()
            print(f"  Logo path: {logo_path}")
            
            academic_year = SchoolConfigService.get_current_academic_year()
            print(f"  Academic year: {academic_year}")
            
            current_term = SchoolConfigService.get_current_term()
            print(f"  Current term: {current_term}")
            
            uses_streams = SchoolConfigService.uses_streams()
            print(f"  Uses streams: {uses_streams}")
            
            grading_system = SchoolConfigService.get_grading_system()
            print(f"  Grading system: {grading_system}")
            
            # Test comprehensive info
            school_info = SchoolConfigService.get_school_info_dict()
            print(f"  School info keys: {list(school_info.keys())}")
            print(f"  School info name: {school_info.get('school_name')}")
            
        return True
        
    except Exception as e:
        print(f"❌ Error testing service: {e}")
        import traceback
        traceback.print_exc()
        return False

def create_sample_school_setup():
    """Create a sample school setup for testing."""
    print("\n=== CREATING SAMPLE SCHOOL SETUP ===")
    
    try:
        from run import create_app
        from models.school_setup import SchoolSetup
        from services.school_config_service import EnhancedSchoolSetupService
        
        app = create_app('development')
        
        with app.app_context():
            # Get current setup
            setup = SchoolSetup.get_current_setup()
            
            # Update with sample data
            sample_data = {
                'school_name': 'Hillview Primary School',
                'school_motto': 'Excellence Through Education',
                'school_vision': 'To be a leading institution in holistic education',
                'school_mission': 'Providing quality education for all learners',
                'school_address': '123 Education Street, Nairobi',
                'postal_address': 'P.O. Box 12345, Nairobi',
                'school_phone': '+254-700-123456',
                'school_mobile': '+254-722-123456',
                'school_email': 'info@hillviewprimary.ac.ke',
                'school_website': 'www.hillviewprimary.ac.ke',
                'registration_number': 'REG/2024/001',
                'ministry_code': 'MIN001',
                'county': 'Nairobi',
                'sub_county': 'Westlands',
                'ward': 'Parklands',
                'constituency': 'Westlands',
                'school_type': 'Private',
                'school_category': 'Primary',
                'education_system': 'CBC',
                'current_academic_year': '2024',
                'current_term': 'Term 1',
                'total_terms_per_year': 3,
                'uses_streams': True,
                'lowest_grade': 'PP1',
                'highest_grade': 'Grade 6',
                'grading_system': 'CBC',
                'max_raw_marks_default': 100,
                'pass_mark_percentage': 50.0,
                'primary_color': '#1f7d53',
                'secondary_color': '#18230f',
                'accent_color': '#4ade80',
                'show_position': True,
                'show_class_average': True,
                'show_subject_teacher': False,
                'report_footer': 'Powered by CbcTeachkit - Hillview Primary School',
                'timezone': 'Africa/Nairobi',
                'language': 'en',
                'currency': 'KES'
            }
            
            # Update the setup
            setup.update_setup(**sample_data)
            print("✅ Sample school setup data created")
            
            # Mark as completed
            setup.mark_setup_completed()
            print("✅ School setup marked as completed")
            
            # Verify the update
            updated_setup = SchoolSetup.get_current_setup()
            print(f"📋 Updated school name: {updated_setup.school_name}")
            print(f"✅ Setup completed: {updated_setup.setup_completed}")
            
        return True
        
    except Exception as e:
        print(f"❌ Error creating sample setup: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Main test function."""
    print("🧪 SCHOOL SETUP TESTING SCRIPT")
    print("=" * 50)

    # Step 1: Check database structure
    if not check_database_structure():
        print("❌ Database structure check failed")
        return

    # Step 2: Test models
    if not test_school_setup_models():
        print("❌ Model testing failed")
        return

    # Step 3: Test service
    if not test_school_config_service():
        print("❌ Service testing failed")
        return

    # Step 4: Create sample setup
    if not create_sample_school_setup():
        print("❌ Sample setup creation failed")
        return

    print("\n" + "=" * 50)
    print("✅ ALL TESTS COMPLETED SUCCESSFULLY!")
    print("🎯 School setup functionality is working correctly")
    print("\nNext steps:")
    print("1. Start the Flask app: python run.py")
    print("2. Login as headteacher")
    print("3. Visit /school-setup to configure your school")
    print("4. The system will now use your school configuration across all pages")
    print("\n🌟 SCHOOL SETUP FEATURES:")
    print("• Plug-and-play deployment for multiple schools")
    print("• Configurable school details (name, address, email, motto, logo)")
    print("• Dynamic updates across entire system")
    print("• Multi-step setup wizard with progress tracking")
    print("• Branding customization (colors, logo)")
    print("• Feature toggles and customization options")
    print("• Academic configuration (terms, grading system)")
    print("• Registration and legal information management")

if __name__ == '__main__':
    main()
