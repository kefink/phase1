#!/usr/bin/env python3
"""
Comprehensive test script to thoroughly test stream population functionality.
"""
import requests
import json
import sqlite3
import os
from requests.sessions import Session

def test_database():
    """Test database structure and data."""
    print("🗃️ TESTING DATABASE")
    print("=" * 50)
    
    db_path = 'kirima_primary.db'
    if not os.path.exists(db_path):
        print("❌ Database file not found!")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Test grades
        cursor.execute('SELECT COUNT(*) FROM grade')
        grade_count = cursor.fetchone()[0]
        print(f"✅ Grades in database: {grade_count}")
        
        if grade_count == 0:
            print("❌ No grades found!")
            return False
        
        # Test streams
        cursor.execute('SELECT COUNT(*) FROM stream')
        stream_count = cursor.fetchone()[0]
        print(f"✅ Streams in database: {stream_count}")
        
        if stream_count == 0:
            print("❌ No streams found!")
            return False
        
        # Test grade-stream relationships
        cursor.execute('''
            SELECT g.name, COUNT(s.id) as stream_count
            FROM grade g
            LEFT JOIN stream s ON g.id = s.grade_id
            GROUP BY g.id, g.name
            ORDER BY g.name
        ''')
        
        relationships = cursor.fetchall()
        print("\n📊 Grade-Stream Relationships:")
        for grade_name, stream_count in relationships:
            print(f"   {grade_name}: {stream_count} streams")
            if stream_count == 0:
                print(f"   ❌ {grade_name} has no streams!")
                return False
        
        # Test teachers
        cursor.execute('SELECT COUNT(*) FROM teacher WHERE role = "classteacher"')
        teacher_count = cursor.fetchone()[0]
        print(f"\n✅ Classteachers in database: {teacher_count}")
        
        if teacher_count == 0:
            print("❌ No classteachers found!")
            return False
        
        # Show sample teacher
        cursor.execute('SELECT username, password FROM teacher WHERE role = "classteacher" LIMIT 1')
        teacher = cursor.fetchone()
        if teacher:
            print(f"   Sample login: {teacher[0]} / {teacher[1]}")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Database error: {e}")
        return False

def test_flask_app():
    """Test if Flask app is running."""
    print("\n🚀 TESTING FLASK APP")
    print("=" * 50)
    
    try:
        response = requests.get("http://localhost:5000", timeout=5)
        print(f"✅ Flask app is running (Status: {response.status_code})")
        return True
    except requests.exceptions.ConnectionError:
        print("❌ Flask app is not running!")
        print("   Please start it with: cd new_structure && python run.py")
        return False
    except Exception as e:
        print(f"❌ Error checking Flask app: {e}")
        return False

def test_login():
    """Test classteacher login functionality with CSRF handling."""
    print("\n🔐 TESTING LOGIN")
    print("=" * 50)

    session = Session()

    # Get login page to extract CSRF token
    try:
        login_response = session.get("http://localhost:5000/classteacher_login")
        print(f"✅ Login page accessible (Status: {login_response.status_code})")

        # Extract CSRF token from the response
        import re
        csrf_match = re.search(r'name="csrf_token" value="([^"]+)"', login_response.text)
        csrf_token = csrf_match.group(1) if csrf_match else None

        if csrf_token:
            print(f"✅ CSRF token extracted: {csrf_token[:20]}...")
        else:
            print("⚠️  No CSRF token found - trying without it")

    except Exception as e:
        print(f"❌ Cannot access login page: {e}")
        return None

    # Attempt login with CSRF token
    login_data = {
        'username': 'classteacher1',
        'password': 'password123'
    }

    if csrf_token:
        login_data['csrf_token'] = csrf_token

    try:
        post_response = session.post("http://localhost:5000/classteacher_login", data=login_data, allow_redirects=False)
        print(f"✅ Login attempt completed (Status: {post_response.status_code})")

        # Check if redirected to dashboard (successful login)
        if post_response.status_code == 302:
            redirect_url = post_response.headers.get('Location', '')
            print(f"✅ Login successful - redirected to: {redirect_url}")

            # Follow the redirect to get to dashboard
            dashboard_response = session.get(redirect_url)
            print(f"✅ Dashboard accessible (Status: {dashboard_response.status_code})")
            return session
        elif post_response.status_code == 200:
            # Check if there's an error message in the response
            if 'Invalid credentials' in post_response.text:
                print("❌ Login failed - Invalid credentials")
            else:
                print("❌ Login failed - stayed on login page")
            return None
        else:
            print(f"❌ Login failed - Status: {post_response.status_code}")
            print(f"   Response: {post_response.text[:200]}...")
            return None

    except Exception as e:
        print(f"❌ Login error: {e}")
        return None

def test_api_endpoints(session=None):
    """Test API endpoints with and without authentication."""
    print("\n📡 TESTING API ENDPOINTS")
    print("=" * 50)
    
    test_grades = ['1', '2', '3', '4', '5']
    
    for grade in test_grades:
        url = f"http://localhost:5000/classteacher/get_streams_by_level/{grade}"
        print(f"\n🧪 Testing grade {grade}: {url}")
        
        # Test without authentication
        try:
            response = requests.get(url, timeout=10)
            print(f"   Without auth - Status: {response.status_code}")
            
            if response.status_code == 401:
                print("   ✅ Correctly requires authentication")
            else:
                print(f"   ⚠️  Unexpected status without auth: {response.status_code}")
                
        except Exception as e:
            print(f"   ❌ Error without auth: {e}")
        
        # Test with authentication (if session available)
        if session:
            try:
                auth_response = session.get(url, timeout=10)
                print(f"   With auth - Status: {auth_response.status_code}")
                
                if auth_response.status_code == 200:
                    try:
                        data = auth_response.json()
                        print(f"   Response: {json.dumps(data, indent=2)}")
                        
                        if data.get('success') and data.get('streams'):
                            print(f"   ✅ SUCCESS: Found {len(data['streams'])} streams")
                            for stream in data['streams']:
                                print(f"      - Stream {stream['name']} (ID: {stream['id']})")
                        else:
                            print(f"   ❌ FAILED: {data.get('message', 'No streams found')}")
                            
                    except json.JSONDecodeError:
                        print(f"   ❌ Invalid JSON response")
                        print(f"   Raw: {auth_response.text[:200]}...")
                else:
                    print(f"   ❌ Failed with auth: {auth_response.status_code}")
                    print(f"   Response: {auth_response.text[:200]}...")
                    
            except Exception as e:
                print(f"   ❌ Error with auth: {e}")

def test_frontend_simulation():
    """Simulate frontend JavaScript behavior."""
    print("\n🌐 TESTING FRONTEND SIMULATION")
    print("=" * 50)
    
    # Login first
    session = Session()
    login_data = {
        'username': 'classteacher1',
        'password': 'password123'
    }
    
    try:
        # Login
        session.post("http://localhost:5000/classteacher_login", data=login_data)
        
        # Get dashboard page
        dashboard_response = session.get("http://localhost:5000/classteacher/")
        print(f"✅ Dashboard accessible (Status: {dashboard_response.status_code})")
        
        # Check if page contains the grade select element
        if 'id="grade"' in dashboard_response.text:
            print("✅ Grade select element found in HTML")
        else:
            print("❌ Grade select element not found in HTML")
        
        # Check if page contains the stream select element
        if 'id="stream"' in dashboard_response.text:
            print("✅ Stream select element found in HTML")
        else:
            print("❌ Stream select element not found in HTML")
        
        # Check if fetchStreams function exists
        if 'fetchStreams' in dashboard_response.text:
            print("✅ fetchStreams function found in JavaScript")
        else:
            print("❌ fetchStreams function not found in JavaScript")
        
        # Simulate the exact API call that JavaScript would make
        print("\n🔄 Simulating JavaScript API calls:")
        
        for grade_num in [1, 2, 3, 4, 5]:
            # This is exactly what the JavaScript does
            api_url = f"http://localhost:5000/classteacher/get_streams_by_level/{grade_num}"
            
            # Add headers that JavaScript would send
            headers = {
                'Accept': 'application/json, text/plain, */*',
                'X-Requested-With': 'XMLHttpRequest'
            }
            
            response = session.get(api_url, headers=headers)
            print(f"   Grade {grade_num}: Status {response.status_code}")
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    if data.get('success') and data.get('streams'):
                        print(f"      ✅ {len(data['streams'])} streams found")
                    else:
                        print(f"      ❌ No streams: {data}")
                except:
                    print(f"      ❌ Invalid JSON")
            else:
                print(f"      ❌ Failed: {response.text[:100]}...")
        
    except Exception as e:
        print(f"❌ Frontend simulation error: {e}")

def main():
    """Run all tests."""
    print("🧪 COMPREHENSIVE STREAM POPULATION TEST")
    print("=" * 60)
    
    # Test 1: Database
    db_ok = test_database()
    
    # Test 2: Flask App
    flask_ok = test_flask_app()
    
    if not flask_ok:
        print("\n❌ Cannot continue without Flask app running")
        return
    
    # Test 3: Login
    session = test_login()
    
    # Test 4: API Endpoints
    test_api_endpoints(session)
    
    # Test 5: Frontend Simulation
    test_frontend_simulation()
    
    # Summary
    print("\n📋 TEST SUMMARY")
    print("=" * 50)
    print(f"Database: {'✅ OK' if db_ok else '❌ FAILED'}")
    print(f"Flask App: {'✅ OK' if flask_ok else '❌ FAILED'}")
    print(f"Login: {'✅ OK' if session else '❌ FAILED'}")
    
    if db_ok and flask_ok and session:
        print("\n🎯 NEXT STEPS:")
        print("1. Open browser: http://localhost:5000/classteacher_login")
        print("2. Login with: classteacher1 / password123")
        print("3. Go to Upload Marks section")
        print("4. Select education level and grade")
        print("5. Check if streams populate")
        print("6. Open browser dev tools (F12) to see console logs")
    else:
        print("\n❌ ISSUES FOUND - Fix these before testing frontend")

if __name__ == '__main__':
    main()
