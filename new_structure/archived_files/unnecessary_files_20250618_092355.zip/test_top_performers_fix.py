#!/usr/bin/env python3
"""
Test script to verify the top performers fix
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from extensions import db
from models import Student, Mark, Grade, Stream, Subject, Term, AssessmentType
from services.academic_analytics_service import AcademicAnalyticsService
from sqlalchemy import func

def test_enhanced_top_performers():
    """Test the enhanced top performers functionality"""
    print("🧪 Testing Enhanced Top Performers Fix...")
    
    try:
        # Test basic database connectivity
        print("📊 Checking database connectivity...")
        student_count = db.session.query(func.count(Student.id)).scalar()
        mark_count = db.session.query(func.count(Mark.id)).scalar()
        print(f"✅ Found {student_count} students and {mark_count} marks")
        
        # Test the enhanced top performers service
        print("🚀 Testing enhanced top performers service...")
        result = AcademicAnalyticsService.get_enhanced_top_performers(limit=5)
        
        print(f"📈 Result keys: {list(result.keys())}")
        
        if 'error' in result:
            print(f"❌ Error in service: {result['error']}")
            return False
            
        enhanced_data = result.get('enhanced_top_performers', {})
        total_grades = result.get('total_grades_analyzed', 0)
        
        print(f"📊 Total grades analyzed: {total_grades}")
        print(f"📊 Enhanced data keys: {list(enhanced_data.keys())}")
        
        if enhanced_data:
            print("✅ Enhanced top performers data found!")
            for grade_name, streams in enhanced_data.items():
                print(f"  📚 Grade: {grade_name}")
                for stream_name, performers in streams.items():
                    print(f"    🏫 Stream: {stream_name} - {len(performers)} performers")
                    if performers:
                        top_performer = performers[0]
                        print(f"      🏆 Top: {top_performer.get('name', 'N/A')} - {top_performer.get('average_percentage', 0)}%")
            return True
        else:
            print("❌ No enhanced top performers data found")
            return False
            
    except Exception as e:
        print(f"💥 Exception occurred: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    # Initialize Flask app context
    from __init__ import create_app
    app = create_app()
    
    with app.app_context():
        success = test_enhanced_top_performers()
        if success:
            print("🎉 Test PASSED - Enhanced top performers fix is working!")
        else:
            print("💔 Test FAILED - Enhanced top performers fix needs more work")
