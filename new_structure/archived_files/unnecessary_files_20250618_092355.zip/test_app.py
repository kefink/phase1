#!/usr/bin/env python3
"""
Simple test script to check if the app can start.
"""

import os
import sys

# Add the current directory to the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_imports():
    """Test if all imports work."""
    print("🔄 Testing imports...")
    
    try:
        print("  - Testing extensions...")
        from extensions import db, csrf
        print("  ✅ Extensions imported successfully")
        
        print("  - Testing config...")
        from config import config
        print("  ✅ Config imported successfully")
        
        print("  - Testing models...")
        from models.user import Teacher
        from models.academic import Subject, Grade, Stream, Term, AssessmentType, Student
        from models.parent import Parent, ParentStudent, ParentEmailLog, EmailTemplate
        print("  ✅ Models imported successfully")
        
        print("  - Testing views...")
        from views import blueprints
        print("  ✅ Views imported successfully")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Import error: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_app_creation():
    """Test if the app can be created."""
    print("\n🔄 Testing app creation...")
    
    try:
        from new_structure import create_app
        app = create_app('development')
        print("  ✅ App created successfully")
        
        # Test database connection
        with app.app_context():
            from extensions import db
            # Try a simple query
            from models.user import Teacher
            teacher_count = Teacher.query.count()
            print(f"  ✅ Database connection successful - {teacher_count} teachers found")
            
            # Check parent tables
            from models.parent import Parent
            parent_count = Parent.query.count()
            print(f"  ✅ Parent portal tables accessible - {parent_count} parents found")
        
        return True
        
    except Exception as e:
        print(f"  ❌ App creation error: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_parent_management():
    """Test if parent management views are accessible."""
    print("\n🔄 Testing parent management...")
    
    try:
        from new_structure import create_app
        app = create_app('development')
        
        with app.test_client() as client:
            # Test if parent management route exists
            response = client.get('/headteacher/parent_management')
            print(f"  - Parent management route status: {response.status_code}")
            
            if response.status_code == 200:
                print("  ✅ Parent management route accessible")
            elif response.status_code == 302:
                print("  ✅ Parent management route exists (redirected - probably needs login)")
            else:
                print(f"  ⚠️ Parent management route returned {response.status_code}")
        
        return True
        
    except Exception as e:
        print(f"  ❌ Parent management test error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    print("🧪 Hillview MVP - Parent Portal Integration Test")
    print("=" * 50)
    
    # Test imports
    imports_ok = test_imports()
    
    if imports_ok:
        # Test app creation
        app_ok = test_app_creation()
        
        if app_ok:
            # Test parent management
            parent_mgmt_ok = test_parent_management()
            
            if parent_mgmt_ok:
                print("\n🎉 All tests passed! Parent portal integration is working!")
                print("\nYou can now:")
                print("1. Run the application with: python run.py")
                print("2. Access parent management at: /headteacher/parent_management")
                print("3. Test parent portal at: /parent/login")
            else:
                print("\n⚠️ Parent management tests failed")
        else:
            print("\n❌ App creation failed")
    else:
        print("\n❌ Import tests failed")
