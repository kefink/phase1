#!/usr/bin/env python3
"""
Test script to check if the streams API endpoint is working correctly.
"""
import requests
import json

def test_streams_api():
    """Test the streams API endpoint."""
    base_url = "http://localhost:5000"
    
    # Test different grade formats
    test_cases = [
        "1", "2", "3", "4", "5", "6", "7", "8", "9",
        "Grade 1", "Grade 2"
    ]
    
    print("🧪 Testing Streams API Endpoint")
    print("=" * 50)
    
    for grade in test_cases:
        url = f"{base_url}/classteacher/get_streams_by_level/{grade}"
        print(f"\n📡 Testing: {url}")
        
        try:
            response = requests.get(url, timeout=10)
            print(f"   Status Code: {response.status_code}")
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    print(f"   Response: {json.dumps(data, indent=2)}")
                    
                    if data.get('success') and data.get('streams'):
                        print(f"   ✅ SUCCESS: Found {len(data['streams'])} streams")
                        for stream in data['streams']:
                            print(f"      - Stream {stream['name']} (ID: {stream['id']})")
                    else:
                        print(f"   ❌ FAILED: {data.get('message', 'No streams found')}")
                        
                except json.JSONDecodeError:
                    print(f"   ❌ FAILED: Invalid JSON response")
                    print(f"   Raw response: {response.text[:200]}...")
            else:
                print(f"   ❌ FAILED: HTTP {response.status_code}")
                print(f"   Response: {response.text[:200]}...")
                
        except requests.exceptions.ConnectionError:
            print(f"   ❌ FAILED: Cannot connect to {base_url}")
            print("   Make sure Flask app is running on localhost:5000")
            break
        except requests.exceptions.Timeout:
            print(f"   ❌ FAILED: Request timeout")
        except Exception as e:
            print(f"   ❌ FAILED: {str(e)}")

def test_login_required():
    """Test if the endpoint requires authentication."""
    print("\n🔐 Testing Authentication Requirement")
    print("=" * 50)
    
    url = "http://localhost:5000/classteacher/get_streams_by_level/1"
    
    try:
        response = requests.get(url, timeout=10)
        print(f"Status Code: {response.status_code}")
        
        if response.status_code == 302:
            print("✅ Endpoint requires authentication (redirecting to login)")
            print("This is expected behavior - you need to login as classteacher first")
        elif response.status_code == 401:
            print("✅ Endpoint requires authentication (unauthorized)")
            print("This is expected behavior - you need to login as classteacher first")
        elif response.status_code == 200:
            print("⚠️  Endpoint allows access without authentication")
            print("This might be unexpected depending on your security requirements")
        else:
            print(f"❓ Unexpected status code: {response.status_code}")
            
    except Exception as e:
        print(f"❌ Error testing authentication: {str(e)}")

def test_flask_app_running():
    """Test if Flask app is running."""
    print("\n🚀 Testing Flask App Status")
    print("=" * 50)
    
    try:
        response = requests.get("http://localhost:5000", timeout=5)
        print(f"✅ Flask app is running (Status: {response.status_code})")
        return True
    except requests.exceptions.ConnectionError:
        print("❌ Flask app is not running or not accessible on localhost:5000")
        return False
    except Exception as e:
        print(f"❌ Error checking Flask app: {str(e)}")
        return False

if __name__ == '__main__':
    print("🔍 API Endpoint Testing Tool")
    print("=" * 50)
    
    # First check if Flask app is running
    if test_flask_app_running():
        test_login_required()
        test_streams_api()
    else:
        print("\n💡 To start the Flask app:")
        print("   cd new_structure")
        print("   python run.py")
        
    print("\n📝 Summary:")
    print("If the API requires authentication, you need to:")
    print("1. Login to the web interface as classteacher")
    print("2. Then test the upload marks functionality")
    print("3. Check browser developer tools for any JavaScript errors")
