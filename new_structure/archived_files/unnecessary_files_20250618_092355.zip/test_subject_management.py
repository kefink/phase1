#!/usr/bin/env python3
"""
Test Subject Management 500 Error
"""

import requests
from bs4 import BeautifulSoup

def test_subject_management():
    """Test subject management page for errors."""
    session = requests.Session()

    # Login
    login_url = 'http://localhost:5000/admin_login'
    response = session.get(login_url)
    soup = BeautifulSoup(response.text, 'html.parser')
    csrf_input = soup.find('input', {'name': 'csrf_token'})
    csrf_token = csrf_input.get('value') if csrf_input else ''

    login_data = {'username': 'headteacher', 'password': 'admin123', 'csrf_token': csrf_token}
    response = session.post(login_url, data=login_data, allow_redirects=False)

    if response.status_code == 302:
        print('✅ Login successful')
        
        # Test subject management
        subject_url = 'http://localhost:5000/headteacher/manage_subjects'
        response = session.get(subject_url)
        print(f'📊 Subject Management status: {response.status_code}')
        
        if response.status_code == 500:
            print('❌ Subject Management has 500 error')
            # Save error details
            with open('subject_management_error.html', 'w', encoding='utf-8') as f:
                f.write(response.text)
            print('Error details saved to subject_management_error.html')
            
            # Extract error information
            if 'File "' in response.text and 'line ' in response.text:
                import re
                file_matches = re.findall(r'File "([^"]+)", line (\d+)', response.text)
                error_matches = re.findall(r'(\w+Error): (.+)', response.text)
                
                print("Error details:")
                for match in file_matches[:3]:  # Show first 3 file references
                    print(f"  File: {match[0]}, Line: {match[1]}")
                
                for match in error_matches[:2]:  # Show first 2 errors
                    print(f"  {match[0]}: {match[1]}")
            
            return False
        else:
            print('✅ Subject Management accessible!')
            return True
    else:
        print('❌ Login failed')
        return False

if __name__ == "__main__":
    test_subject_management()
