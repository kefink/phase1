#!/usr/bin/env python3
"""
Corrected Architecture Test with Actual Routes
Tests the actual implemented routes and analyzes system architecture properly.
"""

import requests
import json
import re
from bs4 import BeautifulSoup
from urllib.parse import urljoin

class CorrectedArchitectureAnalyzer:
    def __init__(self, base_url="http://localhost:5000"):
        """Initialize corrected architecture analyzer."""
        self.base_url = base_url
        self.session = requests.Session()
        self.analysis_results = {}
        
    def login_as_headteacher(self):
        """Login as headteacher for testing."""
        try:
            login_url = urljoin(self.base_url, "/admin_login")
            response = self.session.get(login_url)
            
            if response.status_code != 200:
                return False
            
            soup = BeautifulSoup(response.text, 'html.parser')
            csrf_input = soup.find('input', {'name': 'csrf_token'})
            csrf_token = csrf_input.get('value') if csrf_input else ""
            
            login_data = {
                'username': 'headteacher',
                'password': 'admin123',
                'csrf_token': csrf_token
            }
            
            response = self.session.post(login_url, data=login_data, allow_redirects=False)
            return response.status_code == 302
            
        except Exception as e:
            print(f"Login error: {e}")
            return False
    
    def analyze_dynamic_content(self, soup, page_name):
        """Analyze dynamic content implementation."""
        analysis = {
            'hardcoded_school_names': [],
            'dynamic_data_elements': 0,
            'template_variables': 0,
            'api_endpoints': [],
            'javascript_features': 0,
            'forms_with_csrf': 0,
            'total_forms': 0
        }
        
        page_text = soup.get_text()
        
        # 1. Check for hardcoded school names (should be dynamic)
        hardcoded_patterns = [
            r'Kirima Primary School',
            r'Sample School',
            r'Test School Name'
        ]
        
        for pattern in hardcoded_patterns:
            if re.search(pattern, page_text, re.IGNORECASE):
                analysis['hardcoded_school_names'].append(pattern)
        
        # 2. Count dynamic data elements
        dynamic_selectors = [
            'span[data-count]',
            'div[data-total]',
            '.total-count',
            '.stat-value',
            '.dynamic-content',
            '[id*="total"]',
            '[class*="count"]'
        ]
        
        for selector in dynamic_selectors:
            try:
                elements = soup.select(selector)
                analysis['dynamic_data_elements'] += len(elements)
            except:
                pass
        
        # 3. Find template variables (Flask/Jinja2)
        template_vars = re.findall(r'\{\{[^}]+\}\}', str(soup))
        analysis['template_variables'] = len(template_vars)
        
        # 4. Find API endpoints
        api_endpoints = re.findall(r'["\'](/api/[^"\']+)["\']', str(soup))
        analysis['api_endpoints'] = list(set(api_endpoints))
        
        # 5. Analyze JavaScript functionality
        script_tags = soup.find_all('script')
        js_features = 0
        
        for script in script_tags:
            if script.string:
                # Count modern JavaScript patterns
                patterns = [
                    r'fetch\(',
                    r'addEventListener',
                    r'querySelector',
                    r'getElementById',
                    r'updateData',
                    r'loadData',
                    r'refreshData'
                ]
                
                for pattern in patterns:
                    if re.search(pattern, script.string):
                        js_features += 1
        
        analysis['javascript_features'] = js_features
        
        # 6. Analyze forms and CSRF protection
        forms = soup.find_all('form')
        analysis['total_forms'] = len(forms)
        
        csrf_protected_forms = 0
        for form in forms:
            csrf_token = form.find('input', {'name': 'csrf_token'})
            if csrf_token:
                csrf_protected_forms += 1
        
        analysis['forms_with_csrf'] = csrf_protected_forms
        
        return analysis
    
    def test_page_architecture(self, url, page_name):
        """Test individual page architecture."""
        print(f"\n🔍 Testing {page_name}")
        print("-" * 40)
        
        try:
            response = self.session.get(urljoin(self.base_url, url))
            
            if response.status_code != 200:
                print(f"❌ Cannot access {page_name}: {response.status_code}")
                return {
                    'accessible': False,
                    'status_code': response.status_code,
                    'analysis': None
                }
            
            soup = BeautifulSoup(response.text, 'html.parser')
            analysis = self.analyze_dynamic_content(soup, page_name)
            
            # Print results
            print(f"✅ Page accessible")
            
            if analysis['hardcoded_school_names']:
                print(f"⚠️ Hardcoded school names: {', '.join(analysis['hardcoded_school_names'])}")
            else:
                print(f"✅ No hardcoded school names found")
            
            print(f"📊 Dynamic elements: {analysis['dynamic_data_elements']}")
            print(f"🎭 Template variables: {analysis['template_variables']}")
            print(f"🔌 API endpoints: {len(analysis['api_endpoints'])}")
            print(f"⚡ JavaScript features: {analysis['javascript_features']}")
            print(f"🔒 CSRF protected forms: {analysis['forms_with_csrf']}/{analysis['total_forms']}")
            
            return {
                'accessible': True,
                'status_code': 200,
                'analysis': analysis
            }
            
        except Exception as e:
            print(f"❌ Error testing {page_name}: {e}")
            return {
                'accessible': False,
                'error': str(e),
                'analysis': None
            }
    
    def test_all_interfaces(self):
        """Test all user interfaces with correct routes."""
        print("🎯 COMPREHENSIVE INTERFACE TESTING")
        print("=" * 60)
        
        if not self.login_as_headteacher():
            print("❌ Cannot login - testing will be limited")
            return False
        else:
            print("✅ Logged in as headteacher")
        
        # Correct routes based on actual implementation
        test_pages = {
            'headteacher': [
                ('/headteacher', 'Headteacher Dashboard'),
                ('/headteacher/analytics', 'Analytics Dashboard'),
                ('/headteacher/manage_teachers', 'Teacher Management'),
                ('/headteacher/manage_subjects', 'Subject Management'),
                ('/headteacher/manage_grades_streams', 'Grades & Streams'),
                ('/headteacher/manage_terms_assessments', 'Terms & Assessments'),
                ('/headteacher/reports', 'Reports Dashboard'),
                ('/headteacher/universal_access', 'Universal Access')
            ],
            'classteacher': [
                ('/classteacher', 'Classteacher Dashboard'),
                ('/classteacher/analytics', 'Classteacher Analytics')
            ],
            'teacher': [
                ('/teacher', 'Teacher Dashboard')
            ],
            'parent': [
                ('/parent/profile', 'Parent Profile'),
                ('/parent/dashboard', 'Parent Dashboard')
            ],
            'other_features': [
                ('/subject_config', 'Subject Configuration'),
                ('/parent_management', 'Parent Management'),
                ('/permission', 'Permission Management')
            ]
        }
        
        # Test each interface
        for interface_name, pages in test_pages.items():
            print(f"\n👤 TESTING {interface_name.upper()} INTERFACE")
            print("=" * 50)
            
            interface_results = {}
            
            for url, page_name in pages:
                result = self.test_page_architecture(url, page_name)
                interface_results[page_name] = result
            
            self.analysis_results[interface_name] = interface_results
        
        return True
    
    def generate_comprehensive_report(self):
        """Generate comprehensive architecture report."""
        print("\n📋 COMPREHENSIVE SYSTEM ARCHITECTURE REPORT")
        print("=" * 70)
        
        # Aggregate statistics
        total_pages = 0
        accessible_pages = 0
        pages_with_hardcoded = 0
        total_dynamic_elements = 0
        total_api_endpoints = set()
        total_js_features = 0
        csrf_protected_forms = 0
        total_forms = 0
        
        # Analyze each interface
        for interface_name, pages in self.analysis_results.items():
            print(f"\n📊 {interface_name.upper()} INTERFACE ANALYSIS:")
            print("-" * 40)
            
            interface_accessible = 0
            interface_hardcoded = 0
            
            for page_name, result in pages.items():
                total_pages += 1
                
                if result['accessible']:
                    accessible_pages += 1
                    interface_accessible += 1
                    
                    analysis = result['analysis']
                    if analysis:
                        if analysis['hardcoded_school_names']:
                            pages_with_hardcoded += 1
                            interface_hardcoded += 1
                        
                        total_dynamic_elements += analysis['dynamic_data_elements']
                        total_api_endpoints.update(analysis['api_endpoints'])
                        total_js_features += analysis['javascript_features']
                        csrf_protected_forms += analysis['forms_with_csrf']
                        total_forms += analysis['total_forms']
                        
                        # Page status
                        hardcoded_status = "⚠️" if analysis['hardcoded_school_names'] else "✅"
                        dynamic_status = "✅" if analysis['dynamic_data_elements'] > 0 else "⚠️"
                        
                        print(f"  {hardcoded_status}{dynamic_status} {page_name}: "
                              f"{analysis['dynamic_data_elements']} dynamic, "
                              f"{len(analysis['api_endpoints'])} APIs, "
                              f"{analysis['javascript_features']} JS features")
                else:
                    print(f"  ❌ {page_name}: Not accessible ({result.get('status_code', 'Error')})")
            
            print(f"  📈 Interface Summary: {interface_accessible}/{len(pages)} accessible, "
                  f"{interface_hardcoded} with hardcoded content")
        
        # Overall system assessment
        print(f"\n🎯 OVERALL SYSTEM ASSESSMENT:")
        print("=" * 40)
        print(f"📄 Total pages tested: {total_pages}")
        print(f"✅ Accessible pages: {accessible_pages}/{total_pages} ({accessible_pages/total_pages:.1%})")
        print(f"⚠️ Pages with hardcoded content: {pages_with_hardcoded}/{accessible_pages}")
        print(f"📊 Total dynamic elements: {total_dynamic_elements}")
        print(f"🔌 Unique API endpoints: {len(total_api_endpoints)}")
        print(f"⚡ Total JavaScript features: {total_js_features}")
        print(f"🔒 CSRF protection: {csrf_protected_forms}/{total_forms} forms protected")
        
        # Quality metrics
        accessibility_rate = accessible_pages / total_pages if total_pages > 0 else 0
        hardcoded_rate = pages_with_hardcoded / accessible_pages if accessible_pages > 0 else 0
        dynamic_density = total_dynamic_elements / accessible_pages if accessible_pages > 0 else 0
        csrf_protection_rate = csrf_protected_forms / total_forms if total_forms > 0 else 0
        
        print(f"\n📈 ARCHITECTURE QUALITY METRICS:")
        print(f"  🎯 Accessibility Rate: {accessibility_rate:.1%}")
        print(f"  ⚠️ Hardcoded Content Rate: {hardcoded_rate:.1%}")
        print(f"  📊 Dynamic Elements per Page: {dynamic_density:.1f}")
        print(f"  🔌 API Integration Density: {len(total_api_endpoints)/accessible_pages:.1f} per page")
        print(f"  🔒 CSRF Protection Rate: {csrf_protection_rate:.1%}")
        
        # Final assessment
        print(f"\n🏆 FINAL ARCHITECTURE ASSESSMENT:")
        print("=" * 40)
        
        if (accessibility_rate >= 0.8 and 
            hardcoded_rate <= 0.3 and 
            dynamic_density >= 3 and 
            csrf_protection_rate >= 0.8):
            print("🎉 EXCELLENT SYSTEM ARCHITECTURE!")
            print("✅ High accessibility and functionality")
            print("✅ Good dynamic data implementation")
            print("✅ Strong security practices")
            print("✅ Ready for production deployment")
            return True
        elif (accessibility_rate >= 0.6 and 
              hardcoded_rate <= 0.5 and 
              csrf_protection_rate >= 0.6):
            print("✅ GOOD SYSTEM ARCHITECTURE")
            print("✅ Most features are functional")
            print("⚠️ Some areas for improvement")
            print("✅ Suitable for production with minor fixes")
            return True
        else:
            print("⚠️ SYSTEM ARCHITECTURE NEEDS IMPROVEMENT")
            print("❌ Several issues need to be addressed")
            print("❌ Consider architectural improvements before production")
            return False

def main():
    """Main testing function."""
    print("🏗️ CORRECTED SYSTEM ARCHITECTURE ANALYSIS")
    print("Testing actual implemented routes and features")
    print("=" * 80)
    
    # Test connectivity
    try:
        response = requests.get("http://localhost:5000", timeout=10)
        if response.status_code != 200:
            print(f"❌ Application not accessible: {response.status_code}")
            return False
        print("✅ Application is running and accessible")
    except Exception as e:
        print(f"❌ Cannot connect to application: {e}")
        return False
    
    # Run analysis
    analyzer = CorrectedArchitectureAnalyzer()
    
    if not analyzer.test_all_interfaces():
        print("❌ Interface testing failed")
        return False
    
    architecture_quality = analyzer.generate_comprehensive_report()
    
    if architecture_quality:
        print(f"\n🚀 SYSTEM ARCHITECTURE: PRODUCTION READY!")
        print("✅ All major components are functional")
        print("✅ Good separation of concerns")
        print("✅ Proper security implementation")
        print("✅ Dynamic data handling is working")
    else:
        print(f"\n⚠️ SYSTEM ARCHITECTURE: NEEDS ATTENTION")
        print("Consider addressing the identified issues")
    
    return architecture_quality

if __name__ == "__main__":
    success = main()
    if not success:
        exit(1)
