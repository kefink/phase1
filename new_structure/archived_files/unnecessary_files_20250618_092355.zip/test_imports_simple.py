#!/usr/bin/env python3
"""
Simple Import Test for Security Modules
"""

def test_basic_imports():
    """Test basic security module imports."""
    print("🔒 TESTING BASIC SECURITY IMPORTS")
    print("=" * 40)
    
    results = {'passed': 0, 'failed': 0}
    
    # Test SQL injection protection
    try:
        from security.sql_injection_protection import SQLInjectionProtection
        print("✅ SQL Injection Protection imported")
        results['passed'] += 1
        
        # Test basic functionality
        if not SQLInjectionProtection.validate_input("' OR '1'='1"):
            print("✅ SQL injection detection working")
            results['passed'] += 1
        else:
            print("❌ SQL injection detection failed")
            results['failed'] += 1
            
    except Exception as e:
        print(f"❌ SQL Injection Protection import failed: {e}")
        results['failed'] += 1
    
    # Test XSS protection
    try:
        from security.xss_protection import XSSProtection
        print("✅ XSS Protection imported")
        results['passed'] += 1
        
        # Test basic functionality
        if XSSProtection.detect_xss("<script>alert('test')</script>"):
            print("✅ XSS detection working")
            results['passed'] += 1
        else:
            print("❌ XSS detection failed")
            results['failed'] += 1
            
    except Exception as e:
        print(f"❌ XSS Protection import failed: {e}")
        results['failed'] += 1
    
    # Test RCE protection
    try:
        from security.rce_protection import RCEProtection
        print("✅ RCE Protection imported")
        results['passed'] += 1
        
        # Test basic functionality
        if RCEProtection.detect_command_injection("$(whoami)"):
            print("✅ Command injection detection working")
            results['passed'] += 1
        else:
            print("❌ Command injection detection failed")
            results['failed'] += 1
            
    except Exception as e:
        print(f"❌ RCE Protection import failed: {e}")
        results['failed'] += 1
    
    # Test File Inclusion protection
    try:
        from security.file_inclusion_protection import FileInclusionProtection
        print("✅ File Inclusion Protection imported")
        results['passed'] += 1
        
        # Test basic functionality
        if FileInclusionProtection.detect_lfi_attempt("../../../etc/passwd"):
            print("✅ LFI detection working")
            results['passed'] += 1
        else:
            print("❌ LFI detection failed")
            results['failed'] += 1
            
    except Exception as e:
        print(f"❌ File Inclusion Protection import failed: {e}")
        results['failed'] += 1
    
    # Test SSRF protection
    try:
        from security.ssrf_protection import SSRFProtection
        print("✅ SSRF Protection imported")
        results['passed'] += 1
        
        # Test basic functionality
        if SSRFProtection.is_ip_blocked("127.0.0.1"):
            print("✅ IP blocking working")
            results['passed'] += 1
        else:
            print("❌ IP blocking failed")
            results['failed'] += 1
            
    except Exception as e:
        print(f"❌ SSRF Protection import failed: {e}")
        results['failed'] += 1
    
    # Test Security Manager
    try:
        from security.security_manager import SecurityManager
        print("✅ Security Manager imported")
        results['passed'] += 1
        
        # Test basic functionality
        manager = SecurityManager()
        if not manager.validate_input("' OR '1'='1"):
            print("✅ Security Manager validation working")
            results['passed'] += 1
        else:
            print("❌ Security Manager validation failed")
            results['failed'] += 1
            
    except Exception as e:
        print(f"❌ Security Manager import failed: {e}")
        results['failed'] += 1
    
    # Print results
    total = results['passed'] + results['failed']
    success_rate = (results['passed'] / total * 100) if total > 0 else 0
    
    print(f"\n🎯 IMPORT TEST RESULTS")
    print("=" * 40)
    print(f"✅ Passed: {results['passed']}")
    print(f"❌ Failed: {results['failed']}")
    print(f"📊 Success Rate: {success_rate:.1f}%")
    
    if success_rate >= 90:
        print("🛡️ EXCELLENT - All security modules working!")
    elif success_rate >= 70:
        print("🔒 GOOD - Most security modules working")
    else:
        print("⚠️ ISSUES - Some security modules need fixing")
    
    return results

if __name__ == "__main__":
    test_basic_imports()
