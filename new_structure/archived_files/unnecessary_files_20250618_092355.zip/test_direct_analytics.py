#!/usr/bin/env python3
"""
Direct test of analytics functionality without web interface.
"""
import sys
import os

# Add current directory to path
sys.path.insert(0, '.')

def test_direct_analytics():
    """Test analytics directly using Flask app context."""
    print("🧪 DIRECT ANALYTICS TESTING")
    print("=" * 50)
    
    try:
        # Import Flask app
        from __init__ import create_app
        from services.analytics_service import AnalyticsService
        from models import Student, Mark, Grade, Stream, Subject
        
        app = create_app()
        
        with app.app_context():
            print("✅ Flask app context created")
            
            # Test database connectivity
            student_count = Student.query.count()
            mark_count = Mark.query.count()
            grade_count = Grade.query.count()
            stream_count = Stream.query.count()
            subject_count = Subject.query.count()
            
            print(f"📊 Database Status:")
            print(f"   Students: {student_count}")
            print(f"   Marks: {mark_count}")
            print(f"   Grades: {grade_count}")
            print(f"   Streams: {stream_count}")
            print(f"   Subjects: {subject_count}")
            
            if mark_count == 0:
                print("❌ No marks found - analytics will be empty")
                return False
            
            print("\n🔍 Testing Analytics Service...")
            
            # Test headteacher analytics
            print("1. Testing headteacher analytics...")
            headteacher_analytics = AnalyticsService.get_headteacher_analytics()
            
            if 'error' in headteacher_analytics:
                print(f"❌ Headteacher analytics error: {headteacher_analytics['error']}")
            else:
                print("✅ Headteacher analytics successful")
                print(f"   Has data: {headteacher_analytics.get('has_data', False)}")
                print(f"   Top students: {len(headteacher_analytics.get('top_students', []))}")
                print(f"   Subject performance: {len(headteacher_analytics.get('subject_performance', []))}")
                print(f"   Grade performance: {len(headteacher_analytics.get('grade_performance', []))}")
                
                # Show sample top students
                top_students = headteacher_analytics.get('top_students', [])[:3]
                if top_students:
                    print("\n🏆 TOP 3 STUDENTS:")
                    for i, student in enumerate(top_students, 1):
                        print(f"   {i}. {student.get('name', 'Unknown')} - {student.get('average', 0)}%")
                
                # Show sample subject performance
                subject_performance = headteacher_analytics.get('subject_performance', [])[:3]
                if subject_performance:
                    print("\n📚 TOP 3 SUBJECTS:")
                    for i, subject in enumerate(subject_performance, 1):
                        print(f"   {i}. {subject.get('name', 'Unknown')} - {subject.get('average', 0)}%")
            
            print("\n2. Testing classteacher analytics...")
            # Test with first classteacher
            from models import Teacher
            classteacher = Teacher.query.filter_by(role='classteacher').first()
            
            if classteacher:
                print(f"   Testing with teacher: {classteacher.username}")
                classteacher_analytics = AnalyticsService.get_classteacher_analytics(classteacher.id)
                
                if 'error' in classteacher_analytics:
                    print(f"❌ Classteacher analytics error: {classteacher_analytics['error']}")
                else:
                    print("✅ Classteacher analytics successful")
                    print(f"   Has data: {classteacher_analytics.get('has_data', False)}")
                    print(f"   Top students: {len(classteacher_analytics.get('top_students', []))}")
                    print(f"   Subject performance: {len(classteacher_analytics.get('subject_performance', []))}")
            else:
                print("❌ No classteacher found")
            
            print("\n3. Testing sample data quality...")
            
            # Check for realistic data distribution
            from models import Mark
            marks = Mark.query.all()
            
            if marks:
                percentages = [m.percentage for m in marks if m.percentage is not None]
                if percentages:
                    avg_percentage = sum(percentages) / len(percentages)
                    min_percentage = min(percentages)
                    max_percentage = max(percentages)
                    
                    print(f"   Average percentage: {avg_percentage:.1f}%")
                    print(f"   Range: {min_percentage}% - {max_percentage}%")
                    
                    # Check grade distribution
                    grade_counts = {}
                    for mark in marks:
                        grade = mark.grade_letter
                        grade_counts[grade] = grade_counts.get(grade, 0) + 1
                    
                    print(f"   Grade distribution:")
                    for grade, count in sorted(grade_counts.items()):
                        print(f"     {grade}: {count} marks")
            
            print("\n✅ Direct analytics testing completed successfully!")
            return True
            
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    success = test_direct_analytics()
    if success:
        print("\n🎯 Analytics system is working correctly!")
        print("🌐 You can now test through the web interface:")
        print("   1. Go to http://127.0.0.1:5000")
        print("   2. Click 'Admin Portal'")
        print("   3. Login: username=headteacher, password=admin123")
        print("   4. Navigate to Analytics Dashboard")
    else:
        print("\n❌ Analytics system has issues that need to be resolved.")
