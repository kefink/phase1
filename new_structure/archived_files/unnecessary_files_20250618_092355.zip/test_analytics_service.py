#!/usr/bin/env python3
"""
Direct test of the analytics service to verify enhanced top performers functionality.
"""
import sys
import os
import sqlite3

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_enhanced_top_performers():
    """Test the enhanced top performers functionality directly."""
    print("🧪 TESTING ENHANCED TOP PERFORMERS")
    print("=" * 50)
    
    try:
        # Import the service directly
        from services.academic_analytics_service import AcademicAnalyticsService
        
        print("✅ Successfully imported AcademicAnalyticsService")
        
        # Test the enhanced top performers method
        print("\n📊 Testing get_enhanced_top_performers...")
        
        result = AcademicAnalyticsService.get_enhanced_top_performers(
            grade_id=None,  # All grades
            stream_id=None,  # All streams
            term_id=None,    # Current term
            assessment_type_id=None,  # All assessment types
            limit=5,         # Top 5 per grade/stream
            use_cache=False  # Don't use cache for testing
        )
        
        print(f"✅ Method executed successfully")
        print(f"📈 Result keys: {list(result.keys())}")
        
        enhanced_performers = result.get('enhanced_top_performers', {})
        print(f"📊 Enhanced performers data: {len(enhanced_performers)} grades found")
        
        # Display the results
        for grade_name, streams in enhanced_performers.items():
            print(f"\n🎓 {grade_name}:")
            for stream_name, performers in streams.items():
                print(f"  📚 {stream_name}: {len(performers)} performers")
                
                for i, performer in enumerate(performers[:3], 1):  # Show top 3
                    total_marks = f"{performer.get('total_raw_marks', 'N/A')}/{performer.get('total_max_marks', 'N/A')}"
                    position = performer.get('class_position', 'N/A')
                    total_students = performer.get('total_students_in_class', 'N/A')
                    
                    print(f"    {i}. {performer.get('name', 'Unknown')} ({performer.get('admission_number', 'N/A')})")
                    print(f"       Average: {performer.get('average_percentage', 0)}%")
                    print(f"       Position: #{position} of {total_students} students")
                    print(f"       Total Marks: {total_marks}")
                    print(f"       Subjects: {len(performer.get('subject_marks', []))}")
        
        if enhanced_performers:
            print("\n✅ Enhanced top performers data is working correctly!")
            print("🎯 The new features include:")
            print("   - Total raw marks and maximum marks calculation")
            print("   - Class position within stream")
            print("   - Total students in class for context")
            print("   - Detailed subject breakdown")
            return True
        else:
            print("\n⚠️  No enhanced performers data found")
            return False
            
    except Exception as e:
        print(f"❌ Error testing enhanced top performers: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_database_direct():
    """Test database queries directly to verify data structure."""
    print("\n🗃️  TESTING DATABASE STRUCTURE")
    print("=" * 50)
    
    try:
        conn = sqlite3.connect('kirima_primary.db')
        cursor = conn.cursor()
        
        # Test the enhanced query that the service should use
        print("📊 Testing enhanced analytics query...")
        
        query = """
        SELECT 
            s.id, s.name, s.admission_number,
            g.name as grade_name, st.name as stream_name,
            AVG(m.percentage) as average_percentage,
            COUNT(m.id) as total_marks,
            MIN(m.percentage) as min_percentage,
            MAX(m.percentage) as max_percentage
        FROM student s
        JOIN grade g ON s.grade_id = g.id
        LEFT JOIN stream st ON s.stream_id = st.id
        JOIN mark m ON s.id = m.student_id
        GROUP BY s.id, s.name, s.admission_number, g.name, st.name
        HAVING COUNT(m.id) >= 3
        ORDER BY g.name, st.name, average_percentage DESC
        LIMIT 10
        """
        
        cursor.execute(query)
        results = cursor.fetchall()
        
        print(f"✅ Query executed successfully, found {len(results)} students")
        
        if results:
            print("\n🏆 Sample Top Performers:")
            for i, result in enumerate(results[:5], 1):
                student_id, name, admission_number, grade_name, stream_name, avg_pct, total_marks, min_pct, max_pct = result
                print(f"  {i}. {name} ({admission_number})")
                print(f"     Grade: {grade_name} {stream_name}")
                print(f"     Average: {avg_pct:.1f}% (Range: {min_pct:.1f}% - {max_pct:.1f}%)")
                print(f"     Total Marks: {total_marks}")
                
                # Get subject marks for this student
                cursor.execute("""
                    SELECT sub.name, m.percentage, m.raw_mark, 100 as total_marks, m.grade_letter
                    FROM mark m
                    JOIN subject sub ON m.subject_id = sub.id
                    WHERE m.student_id = ?
                    ORDER BY m.percentage DESC
                """, (student_id,))
                
                subject_marks = cursor.fetchall()
                total_raw_marks = sum(mark[2] for mark in subject_marks if mark[2])
                total_max_marks = len(subject_marks) * 100  # Assuming 100 max per subject
                
                print(f"     Total Raw Marks: {total_raw_marks}/{total_max_marks}")
                print(f"     Subjects: {len(subject_marks)}")
                print()
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Error testing database: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    print("🚀 ANALYTICS SERVICE TESTING")
    print("=" * 60)
    
    # Test database structure first
    db_success = test_database_direct()
    
    # Test the analytics service
    service_success = test_enhanced_top_performers()
    
    print("\n" + "=" * 60)
    if db_success and service_success:
        print("✅ ALL TESTS PASSED!")
        print("🎯 The enhanced analytics features are working correctly.")
        print("📊 Your performance cards should now show:")
        print("   - Total marks (e.g., 700/900)")
        print("   - Class position (#3 of 25 students)")
        print("   - Clean, uncluttered design")
        print("   - Toggle for detailed subject performance")
    else:
        print("❌ SOME TESTS FAILED")
        print("🔧 Check the error messages above for debugging information.")
