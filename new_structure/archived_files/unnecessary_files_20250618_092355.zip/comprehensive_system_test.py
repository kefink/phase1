#!/usr/bin/env python3
"""
Comprehensive System Architecture and Feature Testing
Tests all features from system design, architecture, and software engineering perspectives.
"""

import requests
import json
import time
from bs4 import BeautifulSoup
from urllib.parse import urljoin
import re

class ComprehensiveSystemTester:
    def __init__(self, base_url="http://localhost:5000"):
        """Initialize comprehensive system tester."""
        self.base_url = base_url
        self.session = requests.Session()
        self.test_results = {}
        self.architecture_issues = []
        self.hardcoded_content = []
        self.dynamic_data_issues = []
        
    def extract_csrf_token(self, html_content):
        """Extract CSRF token from HTML."""
        soup = BeautifulSoup(html_content, 'html.parser')
        csrf_input = soup.find('input', {'name': 'csrf_token'})
        return csrf_input.get('value') if csrf_input else ""
    
    def login_as_role(self, role):
        """Login as specific role and return success status."""
        print(f"🔐 Logging in as {role}...")
        
        login_urls = {
            'headteacher': '/admin_login',
            'classteacher': '/classteacher_login',
            'teacher': '/teacher_login',
            'parent': '/parent_login'
        }
        
        credentials = {
            'headteacher': {'username': 'headteacher', 'password': 'admin123'},
            'classteacher': {'username': 'classteacher', 'password': 'teacher123'},
            'teacher': {'username': 'teacher', 'password': 'teacher123'},
            'parent': {'username': 'parent', 'password': 'parent123'}
        }
        
        if role not in login_urls:
            print(f"❌ Unknown role: {role}")
            return False
        
        try:
            # Get login page
            login_url = urljoin(self.base_url, login_urls[role])
            response = self.session.get(login_url)
            
            if response.status_code != 200:
                print(f"❌ Cannot access {role} login page")
                return False
            
            # Extract CSRF token
            csrf_token = self.extract_csrf_token(response.text)
            
            # Prepare login data
            login_data = credentials[role].copy()
            if csrf_token:
                login_data['csrf_token'] = csrf_token
            
            # Submit login
            response = self.session.post(login_url, data=login_data, allow_redirects=False)
            
            if response.status_code == 302:
                print(f"✅ {role} login successful")
                return True
            else:
                print(f"❌ {role} login failed: {response.status_code}")
                return False
                
        except Exception as e:
            print(f"❌ {role} login error: {e}")
            return False
    
    def analyze_page_architecture(self, url, page_name, role):
        """Analyze page architecture and design patterns."""
        print(f"\n🏗️ Analyzing {page_name} Architecture ({role})")
        print("-" * 50)
        
        try:
            response = self.session.get(urljoin(self.base_url, url))
            
            if response.status_code != 200:
                print(f"❌ Cannot access {page_name}: {response.status_code}")
                return False
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 1. Check for hardcoded content
            self.check_hardcoded_content(soup, page_name, role)
            
            # 2. Analyze dynamic data loading
            self.analyze_dynamic_data(soup, page_name, role)
            
            # 3. Check responsive design
            self.check_responsive_design(soup, page_name)
            
            # 4. Analyze JavaScript functionality
            self.analyze_javascript_features(soup, page_name)
            
            # 5. Check API endpoints usage
            self.check_api_integration(soup, page_name)
            
            # 6. Validate form handling
            self.validate_form_architecture(soup, page_name)
            
            return True
            
        except Exception as e:
            print(f"❌ Architecture analysis failed for {page_name}: {e}")
            return False
    
    def check_hardcoded_content(self, soup, page_name, role):
        """Check for hardcoded content that should be dynamic."""
        print("🔍 Checking for hardcoded content...")
        
        # Common hardcoded patterns to look for
        hardcoded_patterns = [
            r'Kirima Primary School',
            r'John Doe',
            r'Sample Teacher',
            r'Test Student',
            r'Grade 1A',
            r'Mathematics - 85%',
            r'2023/2024',
            r'Term 1 2024'
        ]
        
        page_text = soup.get_text()
        found_hardcoded = []
        
        for pattern in hardcoded_patterns:
            if re.search(pattern, page_text, re.IGNORECASE):
                found_hardcoded.append(pattern)
        
        if found_hardcoded:
            print(f"⚠️ Found hardcoded content: {', '.join(found_hardcoded)}")
            self.hardcoded_content.append({
                'page': page_name,
                'role': role,
                'hardcoded_items': found_hardcoded
            })
        else:
            print("✅ No obvious hardcoded content found")
    
    def analyze_dynamic_data(self, soup, page_name, role):
        """Analyze dynamic data loading patterns."""
        print("📊 Analyzing dynamic data patterns...")
        
        # Check for data containers
        data_containers = soup.find_all(['div', 'span', 'td'], class_=re.compile(r'data|count|total|stat'))
        
        # Check for template variables (Flask/Jinja2)
        template_vars = re.findall(r'\{\{[^}]+\}\}', str(soup))
        
        # Check for AJAX endpoints
        ajax_patterns = re.findall(r'/api/[^"\']+', str(soup))
        
        print(f"✅ Found {len(data_containers)} data containers")
        print(f"✅ Found {len(template_vars)} template variables")
        print(f"✅ Found {len(ajax_patterns)} API endpoints")
        
        if len(data_containers) == 0 and len(template_vars) == 0:
            self.dynamic_data_issues.append({
                'page': page_name,
                'role': role,
                'issue': 'No dynamic data containers found'
            })
    
    def check_responsive_design(self, soup, page_name):
        """Check responsive design implementation."""
        print("📱 Checking responsive design...")
        
        # Check for viewport meta tag
        viewport = soup.find('meta', attrs={'name': 'viewport'})
        
        # Check for responsive CSS classes
        responsive_classes = soup.find_all(class_=re.compile(r'col-|row|container|responsive'))
        
        # Check for media queries in style tags
        style_tags = soup.find_all('style')
        media_queries = []
        for style in style_tags:
            if style.string and '@media' in style.string:
                media_queries.append(style.string)
        
        if viewport:
            print("✅ Viewport meta tag found")
        else:
            print("⚠️ No viewport meta tag")
        
        print(f"✅ Found {len(responsive_classes)} responsive CSS classes")
        print(f"✅ Found {len(media_queries)} media queries")
    
    def analyze_javascript_features(self, soup, page_name):
        """Analyze JavaScript functionality and architecture."""
        print("⚡ Analyzing JavaScript features...")
        
        # Find script tags
        script_tags = soup.find_all('script')
        
        # Check for modern JavaScript patterns
        js_patterns = {
            'event_listeners': r'addEventListener|on\w+\s*=',
            'ajax_calls': r'fetch\(|XMLHttpRequest|\$\.ajax|\$\.get|\$\.post',
            'dom_manipulation': r'getElementById|querySelector|innerHTML|textContent',
            'form_validation': r'validate|checkValidity|setCustomValidity',
            'dynamic_updates': r'updateData|refreshData|loadData'
        }
        
        found_patterns = {}
        for script in script_tags:
            if script.string:
                for pattern_name, pattern in js_patterns.items():
                    if re.search(pattern, script.string):
                        found_patterns[pattern_name] = found_patterns.get(pattern_name, 0) + 1
        
        for pattern_name, count in found_patterns.items():
            print(f"✅ {pattern_name}: {count} instances")
        
        if not found_patterns:
            print("⚠️ Limited JavaScript functionality detected")
    
    def check_api_integration(self, soup, page_name):
        """Check API integration patterns."""
        print("🔌 Checking API integration...")
        
        # Look for API endpoints in the HTML
        api_endpoints = re.findall(r'["\'](/api/[^"\']+)["\']', str(soup))
        
        # Look for data attributes that might indicate API usage
        data_attrs = soup.find_all(attrs={'data-url': True})
        
        print(f"✅ Found {len(api_endpoints)} API endpoints")
        print(f"✅ Found {len(data_attrs)} data-url attributes")
        
        if api_endpoints:
            print(f"   API endpoints: {', '.join(set(api_endpoints))}")
    
    def validate_form_architecture(self, soup, page_name):
        """Validate form handling architecture."""
        print("📝 Validating form architecture...")
        
        forms = soup.find_all('form')
        
        for i, form in enumerate(forms):
            form_id = form.get('id', f'form_{i}')
            method = form.get('method', 'GET').upper()
            action = form.get('action', '')
            
            # Check for CSRF protection
            csrf_token = form.find('input', {'name': 'csrf_token'})
            
            # Check for validation attributes
            required_fields = form.find_all(attrs={'required': True})
            
            print(f"   Form {form_id}: {method} {action}")
            print(f"     CSRF: {'✅' if csrf_token else '❌'}")
            print(f"     Required fields: {len(required_fields)}")
    
    def test_headteacher_features(self):
        """Test headteacher page features comprehensively."""
        print("\n👨‍💼 TESTING HEADTEACHER FEATURES")
        print("=" * 60)
        
        if not self.login_as_role('headteacher'):
            return False
        
        headteacher_pages = [
            ('/headteacher', 'Dashboard'),
            ('/headteacher/analytics', 'Analytics'),
            ('/headteacher/manage_teachers', 'Teacher Management'),
            ('/headteacher/manage_students', 'Student Management'),
            ('/headteacher/universal_access', 'Universal Access'),
            ('/headteacher/staff_management', 'Staff Management'),
            ('/headteacher/school_setup', 'School Setup'),
            ('/headteacher/parent_management', 'Parent Management'),
            ('/headteacher/permissions', 'Permissions Management')
        ]
        
        success_count = 0
        for url, name in headteacher_pages:
            if self.analyze_page_architecture(url, name, 'headteacher'):
                success_count += 1
        
        print(f"\n📊 Headteacher Features: {success_count}/{len(headteacher_pages)} analyzed")
        return success_count >= len(headteacher_pages) * 0.8
    
    def test_classteacher_features(self):
        """Test classteacher page features comprehensively."""
        print("\n👩‍🏫 TESTING CLASSTEACHER FEATURES")
        print("=" * 60)
        
        if not self.login_as_role('classteacher'):
            print("⚠️ Classteacher login failed, testing with current session")
        
        classteacher_pages = [
            ('/classteacher', 'Dashboard'),
            ('/classteacher/upload_marks', 'Upload Marks'),
            ('/classteacher/generate_reports', 'Generate Reports'),
            ('/classteacher/view_students', 'View Students'),
            ('/classteacher/analytics', 'Analytics'),
            ('/classteacher/class_management', 'Class Management')
        ]
        
        success_count = 0
        for url, name in classteacher_pages:
            if self.analyze_page_architecture(url, name, 'classteacher'):
                success_count += 1
        
        print(f"\n📊 Classteacher Features: {success_count}/{len(classteacher_pages)} analyzed")
        return success_count >= len(classteacher_pages) * 0.6
    
    def test_teacher_features(self):
        """Test subject teacher page features comprehensively."""
        print("\n👨‍🏫 TESTING SUBJECT TEACHER FEATURES")
        print("=" * 60)
        
        if not self.login_as_role('teacher'):
            print("⚠️ Teacher login failed, testing with current session")
        
        teacher_pages = [
            ('/teacher', 'Dashboard'),
            ('/teacher/my_subjects', 'My Subjects'),
            ('/teacher/upload_marks', 'Upload Marks'),
            ('/teacher/view_students', 'View Students'),
            ('/teacher/reports', 'Reports'),
            ('/teacher/analytics', 'Subject Analytics')
        ]
        
        success_count = 0
        for url, name in teacher_pages:
            if self.analyze_page_architecture(url, name, 'teacher'):
                success_count += 1
        
        print(f"\n📊 Teacher Features: {success_count}/{len(teacher_pages)} analyzed")
        return success_count >= len(teacher_pages) * 0.6
    
    def test_parent_portal_features(self):
        """Test parent portal features comprehensively."""
        print("\n👨‍👩‍👧‍👦 TESTING PARENT PORTAL FEATURES")
        print("=" * 60)
        
        if not self.login_as_role('parent'):
            print("⚠️ Parent login failed, testing with current session")
        
        parent_pages = [
            ('/parent', 'Dashboard'),
            ('/parent/student_reports', 'Student Reports'),
            ('/parent/student_progress', 'Student Progress'),
            ('/parent/communication', 'Communication'),
            ('/parent/profile', 'Profile Management'),
            ('/parent/notifications', 'Notifications')
        ]
        
        success_count = 0
        for url, name in parent_pages:
            if self.analyze_page_architecture(url, name, 'parent'):
                success_count += 1
        
        print(f"\n📊 Parent Portal Features: {success_count}/{len(parent_pages)} analyzed")
        return success_count >= len(parent_pages) * 0.6
    
    def generate_architecture_report(self):
        """Generate comprehensive architecture and design report."""
        print("\n📋 COMPREHENSIVE SYSTEM ARCHITECTURE REPORT")
        print("=" * 70)
        
        # Hardcoded content analysis
        if self.hardcoded_content:
            print("\n⚠️ HARDCODED CONTENT ISSUES:")
            for issue in self.hardcoded_content:
                print(f"   {issue['page']} ({issue['role']}): {', '.join(issue['hardcoded_items'])}")
        else:
            print("\n✅ NO HARDCODED CONTENT ISSUES FOUND")
        
        # Dynamic data analysis
        if self.dynamic_data_issues:
            print("\n⚠️ DYNAMIC DATA ISSUES:")
            for issue in self.dynamic_data_issues:
                print(f"   {issue['page']} ({issue['role']}): {issue['issue']}")
        else:
            print("\n✅ DYNAMIC DATA IMPLEMENTATION LOOKS GOOD")
        
        # Architecture issues
        if self.architecture_issues:
            print("\n⚠️ ARCHITECTURE ISSUES:")
            for issue in self.architecture_issues:
                print(f"   {issue}")
        else:
            print("\n✅ NO MAJOR ARCHITECTURE ISSUES FOUND")
        
        # Overall assessment
        total_issues = len(self.hardcoded_content) + len(self.dynamic_data_issues) + len(self.architecture_issues)
        
        if total_issues == 0:
            print("\n🎉 EXCELLENT SYSTEM ARCHITECTURE!")
            print("✅ All features appear to be properly implemented")
            print("✅ Dynamic data loading is working correctly")
            print("✅ No hardcoded content detected")
            return True
        elif total_issues <= 3:
            print("\n✅ GOOD SYSTEM ARCHITECTURE")
            print(f"⚠️ {total_issues} minor issues found")
            return True
        else:
            print("\n⚠️ SYSTEM ARCHITECTURE NEEDS IMPROVEMENT")
            print(f"❌ {total_issues} issues found")
            return False

def main():
    """Main comprehensive testing function."""
    print("🔬 COMPREHENSIVE SYSTEM ARCHITECTURE & FEATURE TESTING")
    print("Testing from System Design, Architecture, and Software Engineering perspectives")
    print("=" * 80)
    
    tester = ComprehensiveSystemTester()
    
    # Test basic connectivity
    try:
        response = requests.get("http://localhost:5000", timeout=5)
        if response.status_code != 200:
            print(f"❌ Application not accessible: {response.status_code}")
            return False
        print("✅ Application is running and accessible")
    except Exception as e:
        print(f"❌ Cannot connect to application: {e}")
        return False
    
    # Run comprehensive tests
    test_results = {}
    
    test_results['headteacher'] = tester.test_headteacher_features()
    test_results['classteacher'] = tester.test_classteacher_features()
    test_results['teacher'] = tester.test_teacher_features()
    test_results['parent'] = tester.test_parent_portal_features()
    
    # Generate architecture report
    architecture_quality = tester.generate_architecture_report()
    
    # Final assessment
    print(f"\n🎯 FINAL SYSTEM ASSESSMENT")
    print("=" * 50)
    
    passed_tests = sum(1 for result in test_results.values() if result)
    total_tests = len(test_results)
    
    for role, result in test_results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{role.title():<15} {status}")
    
    overall_success = passed_tests >= total_tests * 0.75 and architecture_quality
    
    if overall_success:
        print(f"\n🎉 SYSTEM ARCHITECTURE: EXCELLENT")
        print("✅ All major features are working correctly")
        print("✅ Dynamic data implementation is solid")
        print("✅ No significant hardcoded content")
        print("✅ Ready for production deployment")
    else:
        print(f"\n⚠️ SYSTEM ARCHITECTURE: NEEDS ATTENTION")
        print("Some features or architecture patterns need improvement")
    
    return overall_success

if __name__ == "__main__":
    success = main()
    if not success:
        exit(1)
