#!/usr/bin/env python3
"""
Test MySQL Application Integration
Quick test to verify the application works with MySQL backend.
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from extensions import db
from models.academic import Grade, Stream, Subject, Term, AssessmentType
from models.user import Teacher
from config import config

def test_mysql_integration():
    """Test MySQL integration with the Flask application."""
    print("🧪 Testing MySQL Integration with Flask Application")
    print("=" * 60)
    
    try:
        # Import and create app
        from new_structure import create_app
        
        app = create_app('development')
        
        with app.app_context():
            print("✅ Flask application created successfully")
            
            # Test database connection
            try:
                db.engine.execute("SELECT 1")
                print("✅ Database connection successful")
            except Exception as e:
                print(f"❌ Database connection failed: {e}")
                return False
            
            # Test model queries
            try:
                grade_count = Grade.query.count()
                stream_count = Stream.query.count()
                subject_count = Subject.query.count()
                term_count = Term.query.count()
                assessment_count = AssessmentType.query.count()
                teacher_count = Teacher.query.count()
                
                print(f"✅ Model queries successful:")
                print(f"   - Grades: {grade_count}")
                print(f"   - Streams: {stream_count}")
                print(f"   - Subjects: {subject_count}")
                print(f"   - Terms: {term_count}")
                print(f"   - Assessment Types: {assessment_count}")
                print(f"   - Teachers: {teacher_count}")
                
                if grade_count > 0 and stream_count > 0:
                    print("✅ Data migration verified - core data present")
                else:
                    print("⚠️ No core data found - may need to add students/marks")
                
            except Exception as e:
                print(f"❌ Model query failed: {e}")
                return False
            
            # Test database configuration
            db_uri = app.config.get('SQLALCHEMY_DATABASE_URI', '')
            if 'mysql' in db_uri.lower():
                print("✅ MySQL configuration detected")
                print(f"   Database URI: {db_uri[:50]}...")
            else:
                print(f"❌ Not using MySQL: {db_uri}")
                return False
            
            print("\n🎉 MySQL Integration Test PASSED!")
            print("✅ Application is ready for use with MySQL backend")
            return True
            
    except Exception as e:
        print(f"❌ Application test failed: {e}")
        return False

def main():
    """Main test function."""
    success = test_mysql_integration()
    
    if success:
        print("\n🚀 Ready to proceed with:")
        print("1. Application testing")
        print("2. GitHub push")
        print("3. Production deployment")
    else:
        print("\n⚠️ Issues found - please review before proceeding")
    
    return success

if __name__ == "__main__":
    success = main()
    if not success:
        sys.exit(1)
