#!/usr/bin/env python3
"""
Test script for subject configuration functionality
"""

import requests
import json

def test_subject_config():
    """Test the subject configuration endpoints."""
    
    base_url = "http://localhost:5000"
    
    print("🧪 Testing Subject Configuration System...")
    
    # Test 1: Check if the page loads
    try:
        response = requests.get(f"{base_url}/subject-configuration")
        print(f"📄 Subject Configuration Page: Status {response.status_code}")
        
        if response.status_code == 200:
            print("✅ Page loads successfully")
        else:
            print(f"❌ Page failed to load: {response.text[:200]}")
    
    except Exception as e:
        print(f"❌ Error accessing page: {e}")
    
    # Test 2: Check API endpoints
    api_endpoints = [
        "/api/subject-config/all",
        "/api/subject-config/detect-type/english",
        "/api/subject-config/detect-type/ENGLISH",
        "/api/subject-config/detect-type/kiswahili",
        "/api/subject-info/english/lower_primary"
    ]
    
    for endpoint in api_endpoints:
        try:
            response = requests.get(f"{base_url}{endpoint}")
            print(f"🔌 API {endpoint}: Status {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                if data.get('success'):
                    print(f"  ✅ Success: {len(str(data))} chars response")
                else:
                    print(f"  ⚠️ API returned success=false: {data.get('message', 'No message')}")
            else:
                print(f"  ❌ Failed: {response.text[:100]}")
        
        except Exception as e:
            print(f"  ❌ Error: {e}")
    
    print("\n🎯 Test Summary:")
    print("- If all tests show ✅, the system is working correctly")
    print("- If you see ❌, there may be authentication or configuration issues")
    print("- Try accessing the page through the headteacher dashboard after logging in")

if __name__ == "__main__":
    test_subject_config()
