#!/usr/bin/env python3
"""
Minimal Flask application runner for debugging
"""

import os
import sys
from flask import Flask, render_template, redirect, url_for

def create_minimal_app():
    """Create a minimal Flask application for testing."""
    app = Flask(__name__)
    
    # Basic configuration
    app.config['SECRET_KEY'] = 'dev-secret-key-for-testing'
    app.config['DEBUG'] = True
    
    @app.route('/')
    def index():
        """Basic index route."""
        return '''
        <h1>🎉 Hillview School Management System</h1>
        <h2>✅ Application is running successfully!</h2>
        <p>This is a minimal version to test basic functionality.</p>
        <ul>
            <li><a href="/admin_login">Admin Login</a></li>
            <li><a href="/teacher_login">Teacher Login</a></li>
            <li><a href="/parent_login">Parent Login</a></li>
        </ul>
        '''
    
    @app.route('/admin_login')
    def admin_login():
        """Basic admin login page."""
        return '''
        <h2>Admin Login</h2>
        <form method="POST">
            <p>Username: <input type="text" name="username" required></p>
            <p>Password: <input type="password" name="password" required></p>
            <p><button type="submit">Login</button></p>
        </form>
        <a href="/">← Back to Home</a>
        '''
    
    @app.route('/teacher_login')
    def teacher_login():
        """Basic teacher login page."""
        return '''
        <h2>Teacher Login</h2>
        <form method="POST">
            <p>Username: <input type="text" name="username" required></p>
            <p>Password: <input type="password" name="password" required></p>
            <p><button type="submit">Login</button></p>
        </form>
        <a href="/">← Back to Home</a>
        '''
    
    @app.route('/parent_login')
    def parent_login():
        """Basic parent login page."""
        return '''
        <h2>Parent Login</h2>
        <form method="POST">
            <p>Username: <input type="text" name="username" required></p>
            <p>Password: <input type="password" name="password" required></p>
            <p><button type="submit">Login</button></p>
        </form>
        <a href="/">← Back to Home</a>
        '''
    
    @app.route('/health')
    def health_check():
        """Health check endpoint."""
        return {
            'status': 'healthy',
            'message': 'Hillview School Management System is running',
            'version': '1.0.0'
        }
    
    return app

def main():
    """Main function to run the minimal application."""
    print("🔄 Starting Minimal Hillview School Management System...")
    print("📍 Current directory:", os.getcwd())
    
    try:
        # Create minimal Flask app
        app = create_minimal_app()
        print("✅ Successfully created minimal Flask app")
        
        # Run the application
        print("🚀 Starting Flask development server...")
        print("🌐 Application will be available at: http://localhost:5000")
        print("🔍 Health check available at: http://localhost:5000/health")
        print("⏹️ Press Ctrl+C to stop the server")
        
        app.run(
            host='0.0.0.0',
            port=5000,
            debug=True,
            use_reloader=False  # Disable reloader to avoid import issues
        )
        
    except Exception as e:
        print(f"❌ Error starting application: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
