#!/usr/bin/env python3
"""
Test script to verify template loading for school setup.
"""

import os
import sys
from flask import Flask, render_template

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_template_loading():
    """Test if templates can be loaded properly."""
    
    print("=== Template Loading Test ===")
    print(f"Current directory: {os.getcwd()}")
    print(f"Templates directory exists: {os.path.exists('templates')}")
    print(f"School setup templates exist: {os.path.exists('templates/school_setup')}")
    print(f"Basic info template exists: {os.path.exists('templates/school_setup/basic_info.html')}")
    
    # Create Flask app
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'test-key'
    
    print(f"Flask template folder: {app.template_folder}")
    print(f"Flask root path: {app.root_path}")
    
    # Test template loading
    with app.app_context():
        try:
            # Create a mock setup object
            class MockSetup:
                def __init__(self):
                    self.school_name = "Test School"
                    self.school_motto = "Test Motto"
                    self.school_vision = ""
                    self.school_mission = ""
                    self.school_phone = ""
                    self.school_mobile = ""
                    self.school_email = ""
                    self.school_website = ""
                    self.school_address = ""
                    self.postal_address = ""
            
            setup = MockSetup()
            
            # Try to render the template
            html = render_template('school_setup/basic_info.html', setup=setup)
            print("✅ Template loaded successfully!")
            print(f"Template length: {len(html)} characters")
            
            # Check if key elements are in the rendered HTML
            if "Basic Information" in html:
                print("✅ Template contains expected content")
            else:
                print("❌ Template missing expected content")
                
            return True
            
        except Exception as e:
            print(f"❌ Error loading template: {e}")
            import traceback
            traceback.print_exc()
            return False

if __name__ == '__main__':
    success = test_template_loading()
    if success:
        print("\n🎉 All template tests passed!")
    else:
        print("\n💥 Template tests failed!")
        sys.exit(1)
