#!/usr/bin/env python3
"""
Focused Architecture and Feature Analysis
Analyzes system architecture, dynamic data, and hardcoded content across all user roles.
"""

import requests
import json
import re
from bs4 import BeautifulSoup
from urllib.parse import urljoin

class ArchitectureAnalyzer:
    def __init__(self, base_url="http://localhost:5000"):
        """Initialize architecture analyzer."""
        self.base_url = base_url
        self.session = requests.Session()
        self.analysis_results = {}
        
    def login_as_headteacher(self):
        """Login as headteacher for testing."""
        try:
            # Get login page
            login_url = urljoin(self.base_url, "/admin_login")
            response = self.session.get(login_url)
            
            if response.status_code != 200:
                return False
            
            # Extract CSRF token
            soup = BeautifulSoup(response.text, 'html.parser')
            csrf_input = soup.find('input', {'name': 'csrf_token'})
            csrf_token = csrf_input.get('value') if csrf_input else ""
            
            # Login
            login_data = {
                'username': 'headteacher',
                'password': 'admin123',
                'csrf_token': csrf_token
            }
            
            response = self.session.post(login_url, data=login_data, allow_redirects=False)
            return response.status_code == 302
            
        except Exception as e:
            print(f"Login error: {e}")
            return False
    
    def analyze_page_content(self, url, page_name):
        """Analyze a specific page for architecture patterns."""
        print(f"\n🔍 Analyzing {page_name}")
        print("-" * 40)
        
        try:
            response = self.session.get(urljoin(self.base_url, url))
            
            if response.status_code != 200:
                print(f"❌ Cannot access {page_name}: {response.status_code}")
                return {
                    'accessible': False,
                    'status_code': response.status_code,
                    'hardcoded_content': [],
                    'dynamic_elements': 0,
                    'api_endpoints': [],
                    'forms': 0
                }
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # 1. Check for hardcoded school-specific content
            hardcoded_patterns = [
                r'Kirima Primary School',
                r'Sample School',
                r'Test School',
                r'John Doe',
                r'Sample Teacher',
                r'Test Student',
                r'2023/2024',
                r'Grade 1A.*85%',
                r'Mathematics.*85'
            ]
            
            page_text = soup.get_text()
            found_hardcoded = []
            
            for pattern in hardcoded_patterns:
                if re.search(pattern, page_text, re.IGNORECASE):
                    found_hardcoded.append(pattern)
            
            # 2. Count dynamic elements
            dynamic_selectors = [
                '[data-*]',  # Data attributes
                '.total-*',  # Total counters
                '.count-*',  # Count displays
                '.stat-*',   # Statistics
                '.dynamic-*' # Dynamic content
            ]
            
            dynamic_elements = 0
            for selector in dynamic_selectors:
                try:
                    elements = soup.select(selector)
                    dynamic_elements += len(elements)
                except:
                    pass
            
            # 3. Find API endpoints
            api_endpoints = re.findall(r'["\'](/api/[^"\']+)["\']', str(soup))
            
            # 4. Count forms
            forms = soup.find_all('form')
            
            # 5. Check for template variables
            template_vars = re.findall(r'\{\{[^}]+\}\}', str(soup))
            
            # 6. Check for JavaScript functionality
            script_tags = soup.find_all('script')
            js_functionality = {
                'ajax_calls': 0,
                'event_listeners': 0,
                'dom_manipulation': 0
            }
            
            for script in script_tags:
                if script.string:
                    if re.search(r'fetch\(|XMLHttpRequest|\$\.ajax', script.string):
                        js_functionality['ajax_calls'] += 1
                    if re.search(r'addEventListener|on\w+\s*=', script.string):
                        js_functionality['event_listeners'] += 1
                    if re.search(r'getElementById|querySelector', script.string):
                        js_functionality['dom_manipulation'] += 1
            
            result = {
                'accessible': True,
                'status_code': 200,
                'hardcoded_content': found_hardcoded,
                'dynamic_elements': dynamic_elements,
                'api_endpoints': list(set(api_endpoints)),
                'forms': len(forms),
                'template_vars': len(template_vars),
                'js_functionality': js_functionality
            }
            
            # Print analysis results
            if found_hardcoded:
                print(f"⚠️ Hardcoded content: {', '.join(found_hardcoded)}")
            else:
                print("✅ No hardcoded content detected")
            
            print(f"📊 Dynamic elements: {dynamic_elements}")
            print(f"🔌 API endpoints: {len(api_endpoints)}")
            print(f"📝 Forms: {len(forms)}")
            print(f"🎭 Template variables: {len(template_vars)}")
            print(f"⚡ JS functionality: {sum(js_functionality.values())} features")
            
            return result
            
        except Exception as e:
            print(f"❌ Analysis error: {e}")
            return {
                'accessible': False,
                'error': str(e),
                'hardcoded_content': [],
                'dynamic_elements': 0,
                'api_endpoints': [],
                'forms': 0
            }
    
    def test_all_user_interfaces(self):
        """Test all user interfaces comprehensively."""
        print("🎯 COMPREHENSIVE USER INTERFACE ANALYSIS")
        print("=" * 60)
        
        # Login first
        if not self.login_as_headteacher():
            print("❌ Cannot login - testing public pages only")
        else:
            print("✅ Logged in as headteacher")
        
        # Define pages to test for each role
        pages_to_test = {
            'headteacher': [
                ('/headteacher', 'Headteacher Dashboard'),
                ('/headteacher/analytics', 'Analytics Dashboard'),
                ('/headteacher/manage_teachers', 'Teacher Management'),
                ('/headteacher/manage_students', 'Student Management'),
                ('/headteacher/universal_access', 'Universal Access'),
                ('/headteacher/staff_management', 'Staff Management'),
                ('/headteacher/school_setup', 'School Setup'),
                ('/headteacher/parent_management', 'Parent Management')
            ],
            'classteacher': [
                ('/classteacher', 'Classteacher Dashboard'),
                ('/classteacher/upload_marks', 'Upload Marks'),
                ('/classteacher/generate_reports', 'Generate Reports'),
                ('/classteacher/view_students', 'View Students'),
                ('/classteacher/analytics', 'Classteacher Analytics')
            ],
            'teacher': [
                ('/teacher', 'Teacher Dashboard'),
                ('/teacher/my_subjects', 'My Subjects'),
                ('/teacher/upload_marks', 'Subject Marks Upload'),
                ('/teacher/view_students', 'My Students')
            ],
            'parent': [
                ('/parent', 'Parent Dashboard'),
                ('/parent/student_reports', 'Student Reports'),
                ('/parent/student_progress', 'Student Progress'),
                ('/parent/profile', 'Parent Profile')
            ]
        }
        
        # Test each role's pages
        for role, pages in pages_to_test.items():
            print(f"\n👤 TESTING {role.upper()} INTERFACE")
            print("=" * 50)
            
            role_results = {}
            
            for url, page_name in pages:
                result = self.analyze_page_content(url, page_name)
                role_results[page_name] = result
            
            self.analysis_results[role] = role_results
        
        return True
    
    def generate_architecture_report(self):
        """Generate comprehensive architecture report."""
        print("\n📋 SYSTEM ARCHITECTURE ANALYSIS REPORT")
        print("=" * 70)
        
        total_pages = 0
        accessible_pages = 0
        pages_with_hardcoded = 0
        total_dynamic_elements = 0
        total_api_endpoints = set()
        total_forms = 0
        
        # Analyze results
        for role, pages in self.analysis_results.items():
            print(f"\n📊 {role.upper()} INTERFACE ANALYSIS:")
            print("-" * 40)
            
            role_accessible = 0
            role_hardcoded = 0
            
            for page_name, result in pages.items():
                total_pages += 1
                
                if result['accessible']:
                    accessible_pages += 1
                    role_accessible += 1
                    
                    if result['hardcoded_content']:
                        pages_with_hardcoded += 1
                        role_hardcoded += 1
                    
                    total_dynamic_elements += result['dynamic_elements']
                    total_api_endpoints.update(result['api_endpoints'])
                    total_forms += result['forms']
                    
                    status = "✅" if not result['hardcoded_content'] else "⚠️"
                    print(f"  {status} {page_name}: {result['dynamic_elements']} dynamic elements")
                else:
                    print(f"  ❌ {page_name}: Not accessible")
            
            print(f"  Summary: {role_accessible}/{len(pages)} accessible, {role_hardcoded} with hardcoded content")
        
        # Overall system assessment
        print(f"\n🎯 OVERALL SYSTEM ASSESSMENT:")
        print("=" * 40)
        print(f"📄 Total pages tested: {total_pages}")
        print(f"✅ Accessible pages: {accessible_pages}/{total_pages}")
        print(f"⚠️ Pages with hardcoded content: {pages_with_hardcoded}/{accessible_pages}")
        print(f"📊 Total dynamic elements: {total_dynamic_elements}")
        print(f"🔌 Unique API endpoints: {len(total_api_endpoints)}")
        print(f"📝 Total forms: {total_forms}")
        
        # Architecture quality assessment
        accessibility_rate = accessible_pages / total_pages if total_pages > 0 else 0
        hardcoded_rate = pages_with_hardcoded / accessible_pages if accessible_pages > 0 else 0
        dynamic_density = total_dynamic_elements / accessible_pages if accessible_pages > 0 else 0
        
        print(f"\n📈 QUALITY METRICS:")
        print(f"  Accessibility Rate: {accessibility_rate:.1%}")
        print(f"  Hardcoded Content Rate: {hardcoded_rate:.1%}")
        print(f"  Dynamic Elements per Page: {dynamic_density:.1f}")
        print(f"  API Integration: {len(total_api_endpoints)} endpoints")
        
        # Final assessment
        if accessibility_rate >= 0.8 and hardcoded_rate <= 0.2 and dynamic_density >= 5:
            print(f"\n🎉 EXCELLENT SYSTEM ARCHITECTURE!")
            print("✅ High accessibility rate")
            print("✅ Low hardcoded content")
            print("✅ Good dynamic data implementation")
            print("✅ Proper API integration")
            return True
        elif accessibility_rate >= 0.6 and hardcoded_rate <= 0.4:
            print(f"\n✅ GOOD SYSTEM ARCHITECTURE")
            print("✅ Most features accessible")
            print("⚠️ Some areas for improvement")
            return True
        else:
            print(f"\n⚠️ SYSTEM ARCHITECTURE NEEDS IMPROVEMENT")
            print("❌ Significant issues found")
            return False

def main():
    """Main analysis function."""
    print("🏗️ FOCUSED SYSTEM ARCHITECTURE ANALYSIS")
    print("Analyzing dynamic data, hardcoded content, and feature implementation")
    print("=" * 80)
    
    # Test basic connectivity
    try:
        response = requests.get("http://localhost:5000", timeout=10)
        if response.status_code != 200:
            print(f"❌ Application not accessible: {response.status_code}")
            return False
        print("✅ Application is running and accessible")
    except Exception as e:
        print(f"❌ Cannot connect to application: {e}")
        return False
    
    # Run analysis
    analyzer = ArchitectureAnalyzer()
    
    # Test all interfaces
    analyzer.test_all_user_interfaces()
    
    # Generate report
    architecture_quality = analyzer.generate_architecture_report()
    
    if architecture_quality:
        print(f"\n🚀 SYSTEM READY FOR PRODUCTION!")
        print("✅ Architecture meets enterprise standards")
        print("✅ Dynamic data implementation is solid")
        print("✅ Minimal hardcoded content")
        print("✅ All user interfaces are functional")
    else:
        print(f"\n⚠️ SYSTEM NEEDS ARCHITECTURAL IMPROVEMENTS")
        print("Consider addressing the issues identified above")
    
    return architecture_quality

if __name__ == "__main__":
    success = main()
    if not success:
        exit(1)
