#!/usr/bin/env python3
"""
Check current database configuration and connection
"""

import os
import sys

def check_database_config():
    """Check what database the system is configured to use."""
    print("🔍 CHECKING DATABASE CONFIGURATION")
    print("=" * 50)
    
    # Check config.py
    try:
        from config import config
        dev_config = config['development']
        
        print("📋 Configuration Details:")
        print(f"Database URI: {dev_config.SQLALCHEMY_DATABASE_URI}")
        print(f"MySQL Host: {dev_config.MYSQL_HOST}")
        print(f"MySQL Port: {dev_config.MYSQL_PORT}")
        print(f"MySQL User: {dev_config.MYSQL_USER}")
        print(f"MySQL Database: {dev_config.MYSQL_DATABASE}")
        
        # Check if it's MySQL or SQLite
        if 'mysql' in dev_config.SQLALCHEMY_DATABASE_URI.lower():
            print("✅ System is configured for MySQL")
            database_type = "MySQL"
        elif 'sqlite' in dev_config.SQLALCHEMY_DATABASE_URI.lower():
            print("⚠️ System is configured for SQLite")
            database_type = "SQLite"
        else:
            print("❓ Unknown database type")
            database_type = "Unknown"
            
    except Exception as e:
        print(f"❌ Error reading config: {e}")
        return
    
    # Check for existing database files
    print(f"\n📁 CHECKING FOR DATABASE FILES")
    print("-" * 30)
    
    # Check for SQLite files
    sqlite_files = []
    for file in os.listdir('.'):
        if file.endswith(('.db', '.sqlite', '.sqlite3')):
            size = os.path.getsize(file)
            sqlite_files.append((file, size))
    
    if sqlite_files:
        print("📄 Found SQLite database files:")
        for file, size in sqlite_files:
            print(f"  - {file} ({size:,} bytes)")
    else:
        print("📄 No SQLite database files found")
    
    # Test database connection
    print(f"\n🔌 TESTING DATABASE CONNECTION")
    print("-" * 30)
    
    try:
        if database_type == "MySQL":
            # Test MySQL connection
            import pymysql
            connection = pymysql.connect(
                host=dev_config.MYSQL_HOST,
                port=dev_config.MYSQL_PORT,
                user=dev_config.MYSQL_USER,
                password=dev_config.MYSQL_PASSWORD,
                database=dev_config.MYSQL_DATABASE
            )
            cursor = connection.cursor()
            cursor.execute("SELECT VERSION()")
            version = cursor.fetchone()
            print(f"✅ MySQL connection successful!")
            print(f"   MySQL version: {version[0]}")
            
            # Check tables
            cursor.execute("SHOW TABLES")
            tables = cursor.fetchall()
            print(f"   Tables found: {len(tables)}")
            if tables:
                print("   Table list:")
                for table in tables[:10]:  # Show first 10 tables
                    print(f"     - {table[0]}")
                if len(tables) > 10:
                    print(f"     ... and {len(tables) - 10} more")
            
            connection.close()
            
        elif database_type == "SQLite":
            import sqlite3
            # Check which SQLite file to use
            if sqlite_files:
                db_file = sqlite_files[0][0]  # Use the first one
                print(f"Testing SQLite connection to: {db_file}")
                
                connection = sqlite3.connect(db_file)
                cursor = connection.cursor()
                cursor.execute("SELECT sqlite_version()")
                version = cursor.fetchone()
                print(f"✅ SQLite connection successful!")
                print(f"   SQLite version: {version[0]}")
                
                # Check tables
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = cursor.fetchall()
                print(f"   Tables found: {len(tables)}")
                if tables:
                    print("   Table list:")
                    for table in tables[:10]:  # Show first 10 tables
                        print(f"     - {table[0]}")
                    if len(tables) > 10:
                        print(f"     ... and {len(tables) - 10} more")
                
                connection.close()
            
    except Exception as e:
        print(f"❌ Database connection failed: {e}")
    
    # Summary
    print(f"\n📊 SUMMARY")
    print("=" * 50)
    print(f"Configuration: {database_type}")
    print(f"SQLite files present: {'Yes' if sqlite_files else 'No'}")
    
    if database_type == "MySQL" and sqlite_files:
        print("\n⚠️ IMPORTANT NOTICE:")
        print("Your system is configured for MySQL but SQLite files are present.")
        print("This suggests you may be in a transition state.")
        print("\nRecommendations:")
        print("1. If you want to use MySQL: Ensure MySQL is running and migrate data")
        print("2. If you want to use SQLite: Update config.py to use SQLite")
        print("3. Remove unused database files to avoid confusion")

if __name__ == "__main__":
    check_database_config()
