#!/usr/bin/env python3
"""
Simple test to check if login works by temporarily bypassing the decorator.
"""
import requests
import re

def test_simple_login():
    """Test login with a simple approach."""
    print("🔐 SIMPLE LOGIN TEST")
    print("=" * 50)
    
    try:
        session = requests.Session()
        
        # Get login page
        login_url = "http://localhost:5000/classteacher_login"
        response = session.get(login_url)
        
        if response.status_code != 200:
            print(f"❌ Cannot access login page: {response.status_code}")
            return False
        
        print(f"✅ Login page accessible: {response.status_code}")
        
        # Extract CSRF token
        csrf_match = re.search(r'name="csrf_token" value="([^"]+)"', response.text)
        
        if not csrf_match:
            print("❌ No CSRF token found")
            return False
        
        csrf_token = csrf_match.group(1)
        print(f"✅ CSRF token: {csrf_token[:20]}...")
        
        # Submit login form
        login_data = {
            'username': 'classteacher1',
            'password': 'password123',
            'csrf_token': csrf_token
        }
        
        print("📤 Submitting login...")
        post_response = session.post(login_url, data=login_data, allow_redirects=True)
        
        print(f"📥 Final URL: {post_response.url}")
        print(f"📥 Status: {post_response.status_code}")
        
        # Check what we got
        if 'classteacher' in post_response.url:
            print("✅ Successfully redirected to classteacher area!")
            
            # Check if we can access the dashboard content
            if 'Class Teacher Dashboard' in post_response.text:
                print("✅ Dashboard content loaded successfully!")
                return True
            else:
                print("❌ Redirected but dashboard content not found")
                print(f"   Page title: {extract_title(post_response.text)}")
                return False
        elif 'login' in post_response.url:
            print("❌ Still on login page")
            
            # Check for error messages
            if 'Invalid credentials' in post_response.text:
                print("   Error: Invalid credentials")
            elif 'error' in post_response.text.lower():
                print("   Error found in response")
                # Try to extract error
                error_match = re.search(r'class="error[^"]*"[^>]*>([^<]+)', post_response.text)
                if error_match:
                    print(f"   Error message: {error_match.group(1).strip()}")
            else:
                print("   No specific error found")
            return False
        else:
            print(f"❌ Unexpected redirect to: {post_response.url}")
            return False
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return False

def extract_title(html):
    """Extract page title from HTML."""
    title_match = re.search(r'<title>([^<]+)</title>', html)
    return title_match.group(1) if title_match else "No title found"

def test_direct_dashboard_access():
    """Test if we can access dashboard directly after login."""
    print("\n🏠 DIRECT DASHBOARD ACCESS TEST")
    print("=" * 50)
    
    try:
        session = requests.Session()
        
        # First login
        login_url = "http://localhost:5000/classteacher_login"
        response = session.get(login_url)
        
        csrf_match = re.search(r'name="csrf_token" value="([^"]+)"', response.text)
        if not csrf_match:
            print("❌ Cannot get CSRF token")
            return False
        
        csrf_token = csrf_match.group(1)
        
        login_data = {
            'username': 'classteacher1',
            'password': 'password123',
            'csrf_token': csrf_token
        }
        
        # Submit login (don't follow redirects)
        post_response = session.post(login_url, data=login_data, allow_redirects=False)
        
        print(f"Login response status: {post_response.status_code}")
        
        if post_response.status_code == 302:
            redirect_url = post_response.headers.get('Location', '')
            print(f"Redirect URL: {redirect_url}")
            
            # Now try to access the dashboard directly
            dashboard_url = "http://localhost:5000/classteacher/"
            dashboard_response = session.get(dashboard_url)
            
            print(f"Dashboard access status: {dashboard_response.status_code}")
            print(f"Dashboard URL: {dashboard_response.url}")
            
            if dashboard_response.status_code == 200:
                if 'Class Teacher Dashboard' in dashboard_response.text:
                    print("✅ Dashboard accessible after login!")
                    return True
                else:
                    print("❌ Dashboard page loaded but content missing")
                    print(f"   Page title: {extract_title(dashboard_response.text)}")
            else:
                print(f"❌ Cannot access dashboard: {dashboard_response.status_code}")
        else:
            print(f"❌ Login failed: {post_response.status_code}")
        
        return False
        
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def main():
    """Run tests."""
    print("🧪 SIMPLE LOGIN TESTS")
    print("=" * 60)
    
    # Test 1: Simple login with redirects
    login_ok = test_simple_login()
    
    # Test 2: Direct dashboard access
    dashboard_ok = test_direct_dashboard_access()
    
    print("\n📋 RESULTS")
    print("=" * 50)
    print(f"Login Test: {'✅ PASSED' if login_ok else '❌ FAILED'}")
    print(f"Dashboard Test: {'✅ PASSED' if dashboard_ok else '❌ FAILED'}")
    
    if login_ok and dashboard_ok:
        print("\n🎯 LOGIN IS WORKING!")
        print("The issue might be with the stream population API, not login.")
        print("Try logging in manually and test the upload marks functionality.")
    else:
        print("\n❌ LOGIN ISSUES REMAIN")
        print("Need to investigate further.")

if __name__ == '__main__':
    main()
