#!/usr/bin/env python3
"""
Simple Dashboard Test
Tests the dashboard functionality by making a direct request.
"""

import requests
from bs4 import BeautifulSoup
import re

def test_dashboard_access():
    """Test dashboard access with proper login."""
    print("🔐 Testing Dashboard Access")
    print("=" * 30)
    
    session = requests.Session()
    
    try:
        # Step 1: Get login page and CSRF token
        login_url = "http://localhost:5000/admin_login"
        response = session.get(login_url)
        
        if response.status_code != 200:
            print(f"❌ Cannot access login page: {response.status_code}")
            return False
        
        # Extract CSRF token
        soup = BeautifulSoup(response.text, 'html.parser')
        csrf_input = soup.find('input', {'name': 'csrf_token'})
        csrf_token = csrf_input.get('value') if csrf_input else ""
        
        print(f"✅ Login page accessible, CSRF token: {csrf_token[:20]}...")
        
        # Step 2: Login
        login_data = {
            'username': 'headteacher',
            'password': 'admin123',
            'csrf_token': csrf_token
        }
        
        response = session.post(login_url, data=login_data, allow_redirects=False)
        
        if response.status_code != 302:
            print(f"❌ Login failed: {response.status_code}")
            print(f"Response text: {response.text[:500]}")
            return False
        
        print("✅ Login successful")
        
        # Step 3: Access dashboard
        dashboard_url = "http://localhost:5000/headteacher"
        response = session.get(dashboard_url)
        
        print(f"📊 Dashboard response status: {response.status_code}")
        
        if response.status_code == 200:
            print("✅ Dashboard accessible!")
            
            # Check for key content
            content = response.text.lower()
            indicators = ['dashboard', 'students', 'teachers', 'analytics']
            found = [ind for ind in indicators if ind in content]
            print(f"✅ Found content indicators: {', '.join(found)}")
            
            return True
            
        elif response.status_code == 500:
            print("❌ Dashboard has a 500 error")
            
            # Try to extract error information
            if 'traceback' in response.text.lower() or 'error' in response.text.lower():
                print("Error details found in response:")
                # Look for error patterns
                error_patterns = [
                    r'File "([^"]+)", line (\d+)',
                    r'(\w+Error): (.+)',
                    r'Exception: (.+)'
                ]
                
                for pattern in error_patterns:
                    matches = re.findall(pattern, response.text)
                    if matches:
                        print(f"  Pattern '{pattern}' matches: {matches[:3]}")  # Show first 3 matches
            
            # Save error response for debugging
            with open('dashboard_error.html', 'w', encoding='utf-8') as f:
                f.write(response.text)
            print("❌ Error response saved to dashboard_error.html")
            
            return False
            
        else:
            print(f"❌ Unexpected dashboard response: {response.status_code}")
            return False
            
    except Exception as e:
        print(f"❌ Test failed with exception: {e}")
        return False

def main():
    """Main test function."""
    print("🧪 SIMPLE DASHBOARD TEST")
    print("=" * 40)
    
    # Test basic connectivity
    try:
        response = requests.get("http://localhost:5000", timeout=5)
        print(f"✅ Application accessible: {response.status_code}")
    except Exception as e:
        print(f"❌ Cannot connect to application: {e}")
        return False
    
    # Test dashboard access
    success = test_dashboard_access()
    
    if success:
        print("\n🎉 DASHBOARD TEST PASSED!")
        print("✅ Login working")
        print("✅ Dashboard accessible")
        print("✅ System ready for use")
    else:
        print("\n❌ DASHBOARD TEST FAILED!")
        print("Check dashboard_error.html for detailed error information")
    
    return success

if __name__ == "__main__":
    success = main()
    if not success:
        exit(1)
