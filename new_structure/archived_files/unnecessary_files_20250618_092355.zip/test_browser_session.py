#!/usr/bin/env python3
"""
Test the enhanced top performers API with a proper session (simulating browser login).
"""
import requests
import json

def test_with_session():
    """Test the API with a proper login session."""
    print("🧪 TESTING WITH BROWSER SESSION SIMULATION")
    print("=" * 60)
    
    # Create a session
    session = requests.Session()
    base_url = "http://127.0.0.1:5000"
    
    try:
        # Step 1: Login as headteacher
        print("🔐 Step 1: Logging in as headteacher...")
        login_data = {
            'username': 'headteacher',
            'password': 'admin123'
        }
        
        login_response = session.post(f"{base_url}/auth/login", data=login_data)
        print(f"📈 Login Status: {login_response.status_code}")
        
        if login_response.status_code != 200:
            print(f"❌ Login failed: {login_response.text}")
            return False
        
        # Step 2: Test the enhanced top performers API
        print("\n📊 Step 2: Testing enhanced top performers API...")
        api_url = f"{base_url}/api/analytics/enhanced-top-performers"
        params = {'limit': 5}
        
        api_response = session.get(api_url, params=params)
        print(f"📈 API Status: {api_response.status_code}")
        
        if api_response.status_code == 200:
            data = api_response.json()
            print(f"✅ API Response received")
            print(f"🔑 Response keys: {list(data.keys())}")
            
            if data.get('success'):
                enhanced_performers = data.get('enhanced_top_performers', {})
                print(f"📊 Enhanced performers: {len(enhanced_performers)} grades found")
                
                # Show sample data
                for grade_name, streams in list(enhanced_performers.items())[:2]:
                    print(f"\n🎓 {grade_name}:")
                    for stream_name, performers in list(streams.items())[:1]:
                        print(f"  📚 {stream_name}: {len(performers)} performers")
                        if performers:
                            sample = performers[0]
                            print(f"    Sample: {sample.get('name')} - {sample.get('average_percentage')}%")
                            print(f"    Total marks: {sample.get('total_raw_marks')}/{sample.get('total_max_marks')}")
                
                print(f"\n✅ Enhanced top performers API is working correctly!")
                return True
            else:
                print(f"❌ API returned success=False: {data.get('message')}")
                return False
        else:
            print(f"❌ API Error {api_response.status_code}: {api_response.text}")
            return False
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def test_comprehensive_api_with_session():
    """Test the comprehensive API with session."""
    print("\n🧪 TESTING COMPREHENSIVE API WITH SESSION")
    print("=" * 60)
    
    session = requests.Session()
    base_url = "http://127.0.0.1:5000"
    
    try:
        # Login
        login_data = {'username': 'headteacher', 'password': 'admin123'}
        login_response = session.post(f"{base_url}/auth/login", data=login_data)
        
        if login_response.status_code != 200:
            print(f"❌ Login failed")
            return False
        
        # Test comprehensive API
        api_response = session.get(f"{base_url}/api/analytics/comprehensive")
        print(f"📈 Comprehensive API Status: {api_response.status_code}")
        
        if api_response.status_code == 200:
            data = api_response.json()
            if data.get('success'):
                analytics = data.get('analytics', {})
                summary = analytics.get('summary', {})
                print(f"✅ Comprehensive API working")
                print(f"📊 Students: {summary.get('total_students_analyzed', 0)}")
                print(f"📚 Subjects: {summary.get('total_subjects_analyzed', 0)}")
                print(f"🏆 Top performers: {len(analytics.get('topPerformers', []))}")
                return True
            else:
                print(f"❌ Comprehensive API failed: {data.get('message')}")
                return False
        else:
            print(f"❌ Comprehensive API Error: {api_response.status_code}")
            return False
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

if __name__ == '__main__':
    print("🚀 BROWSER SESSION SIMULATION TEST")
    print("=" * 70)
    
    enhanced_success = test_with_session()
    comprehensive_success = test_comprehensive_api_with_session()
    
    print("\n" + "=" * 70)
    print("📊 SESSION TEST RESULTS:")
    print(f"   Enhanced API: {'✅ PASS' if enhanced_success else '❌ FAIL'}")
    print(f"   Comprehensive API: {'✅ PASS' if comprehensive_success else '❌ FAIL'}")
    
    if enhanced_success and comprehensive_success:
        print("\n🎯 Both APIs are working with proper authentication!")
        print("💡 The issue might be:")
        print("   1. Browser cache not refreshing JavaScript")
        print("   2. JavaScript errors preventing execution")
        print("   3. HTML template issues")
        print("\n🔧 Try:")
        print("   1. Hard refresh (Ctrl+F5)")
        print("   2. Check browser console for errors")
        print("   3. Call testEnhancedTopPerformers() in console")
    else:
        print("\n🔧 API authentication issues need to be resolved first.")
