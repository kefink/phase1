#!/usr/bin/env python3
"""
Test script to verify analytics fixes are working.
"""

import sys
import os
import sqlite3

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_database_connection():
    """Test basic database connection and structure."""
    print("🔍 Testing database connection...")
    
    try:
        # Check if database exists
        db_path = 'kirima_primary.db'
        if not os.path.exists(db_path):
            print(f"❌ Database not found: {db_path}")
            return False
            
        print(f"✅ Database found: {db_path}")
        
        # Connect and check basic structure
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check mark table structure
        cursor.execute("PRAGMA table_info(mark)")
        columns = cursor.fetchall()
        print(f"📋 Mark table columns:")
        for col in columns:
            print(f"  - {col[1]} ({col[2]})")
            
        # Check if we have the correct 'mark' column (not 'marks')
        column_names = [col[1] for col in columns]
        if 'mark' in column_names:
            print("✅ Correct 'mark' column found")
        else:
            print("❌ 'mark' column not found")
            
        # Test a simple query
        cursor.execute("SELECT COUNT(*) FROM mark")
        mark_count = cursor.fetchone()[0]
        print(f"📊 Total marks in database: {mark_count}")
        
        if mark_count > 0:
            # Test accessing the mark column
            cursor.execute("SELECT id, mark, total_marks FROM mark LIMIT 1")
            sample = cursor.fetchone()
            print(f"✅ Sample mark record: ID={sample[0]}, mark={sample[1]}, total={sample[2]}")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"❌ Database test failed: {e}")
        return False

def test_analytics_service():
    """Test the analytics service imports and basic functionality."""
    print("\n🔍 Testing analytics service...")
    
    try:
        from services.academic_analytics_service import AcademicAnalyticsService
        print("✅ AcademicAnalyticsService imported successfully")
        
        # Test basic method exists
        if hasattr(AcademicAnalyticsService, 'get_enhanced_top_performers'):
            print("✅ get_enhanced_top_performers method exists")
        else:
            print("❌ get_enhanced_top_performers method missing")
            
        return True
        
    except Exception as e:
        print(f"❌ Analytics service test failed: {e}")
        return False

def test_analytics_api():
    """Test the analytics API imports."""
    print("\n🔍 Testing analytics API...")
    
    try:
        from views.analytics_api import get_top_subject_performers
        print("✅ get_top_subject_performers imported successfully")
        
        return True
        
    except Exception as e:
        print(f"❌ Analytics API test failed: {e}")
        return False

def test_enhanced_top_performers_data_structure():
    """Test that enhanced top performers returns the correct data structure."""
    print("\n🔍 Testing enhanced top performers data structure...")
    
    try:
        from services.academic_analytics_service import AcademicAnalyticsService
        from extensions import db
        from models.academic import Term, AssessmentType
        
        # Create a minimal Flask app context for testing
        from flask import Flask
        app = Flask(__name__)
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///kirima_primary.db'
        app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
        
        db.init_app(app)
        
        with app.app_context():
            # Test the method with minimal parameters
            result = AcademicAnalyticsService.get_enhanced_top_performers(limit=1)
            
            print(f"✅ Enhanced top performers method executed")
            print(f"📊 Result keys: {list(result.keys())}")
            
            if 'enhanced_top_performers' in result:
                performers = result['enhanced_top_performers']
                print(f"📊 Enhanced top performers structure: {type(performers)}")
                
                # Check if we have any data
                if performers:
                    # Get first grade/stream data
                    for grade_key, streams in performers.items():
                        print(f"📊 Grade: {grade_key}")
                        for stream_key, students in streams.items():
                            print(f"📊 Stream: {stream_key}")
                            if students:
                                student = students[0]
                                print(f"📊 Sample student fields: {list(student.keys())}")
                                
                                # Check for the required fields for delete functionality
                                required_fields = ['grade', 'stream', 'term', 'assessment_type']
                                missing_fields = [field for field in required_fields if field not in student]
                                
                                if missing_fields:
                                    print(f"❌ Missing fields for delete functionality: {missing_fields}")
                                else:
                                    print(f"✅ All required fields present for delete functionality")
                                    print(f"   - grade: {student.get('grade')}")
                                    print(f"   - stream: {student.get('stream')}")
                                    print(f"   - term: {student.get('term')}")
                                    print(f"   - assessment_type: {student.get('assessment_type')}")
                            break
                        break
                else:
                    print("ℹ️ No enhanced top performers data found (this is normal if no marks exist)")
            
        return True
        
    except Exception as e:
        print(f"❌ Enhanced top performers test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run all tests."""
    print("🚀 Starting Analytics Fixes Test Suite")
    print("=" * 50)
    
    tests = [
        test_database_connection,
        test_analytics_service,
        test_analytics_api,
        test_enhanced_top_performers_data_structure
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        try:
            if test():
                passed += 1
        except Exception as e:
            print(f"❌ Test {test.__name__} crashed: {e}")
    
    print("\n" + "=" * 50)
    print(f"📊 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! Analytics fixes are working correctly.")
    else:
        print("⚠️ Some tests failed. Check the output above for details.")
    
    return passed == total

if __name__ == '__main__':
    success = main()
    sys.exit(0 if success else 1)
