#!/usr/bin/env python3
"""
Test script to check analytics functionality after fixes.
"""
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from new_structure import create_app
from extensions import db

app = create_app('development')
from models.academic import Mark, Student, Subject, Grade, Stream, Term, AssessmentType
from models.user import Teacher
from sqlalchemy import func, desc

def test_analytics_data():
    """Test analytics data availability and structure."""
    with app.app_context():
        print("=== ANALYTICS DATA TEST ===")
        
        # Check basic data counts
        marks_count = Mark.query.count()
        students_count = Student.query.count()
        subjects_count = Subject.query.count()
        grades_count = Grade.query.count()
        streams_count = Stream.query.count()
        terms_count = Term.query.count()
        assessment_types_count = AssessmentType.query.count()
        
        print(f"\nDatabase Counts:")
        print(f"  Marks: {marks_count}")
        print(f"  Students: {students_count}")
        print(f"  Subjects: {subjects_count}")
        print(f"  Grades: {grades_count}")
        print(f"  Streams: {streams_count}")
        print(f"  Terms: {terms_count}")
        print(f"  Assessment Types: {assessment_types_count}")
        
        if marks_count == 0:
            print("\n❌ No marks data available - analytics will be empty")
            return
        
        # Test the fixed join logic
        print(f"\n=== TESTING FIXED JOIN LOGIC ===")
        try:
            # Test the corrected joins
            base_query = Mark.query\
                .join(Student, Mark.student_id == Student.id)\
                .join(Subject, Mark.subject_id == Subject.id)\
                .join(Grade, Student.grade_id == Grade.id)\
                .outerjoin(Stream, Student.stream_id == Stream.id)\
                .join(Term, Mark.term_id == Term.id)\
                .join(AssessmentType, Mark.assessment_type_id == AssessmentType.id)
            
            # Get combinations
            combinations = base_query.with_entities(
                Grade.id.label('grade_id'),
                Grade.name.label('grade_name'),
                Stream.id.label('stream_id'),
                Stream.name.label('stream_name'),
                Subject.id.label('subject_id'),
                Subject.name.label('subject_name')
            ).distinct().all()
            
            print(f"✅ Join logic works! Found {len(combinations)} combinations")
            
            # Show sample combinations
            print(f"\nSample combinations:")
            for i, combo in enumerate(combinations[:5]):
                stream_name = combo.stream_name if combo.stream_name else "No Stream"
                print(f"  {i+1}. Grade {combo.grade_name} - {stream_name} - {combo.subject_name}")
            
            # Test top performers query for first combination
            if combinations:
                combo = combinations[0]
                print(f"\n=== TESTING TOP PERFORMERS FOR: Grade {combo.grade_name} - {combo.stream_name or 'No Stream'} - {combo.subject_name} ===")
                
                top_performers_query = base_query.filter(
                    Grade.id == combo.grade_id,
                    Subject.id == combo.subject_id
                )
                
                # Add stream filter
                if combo.stream_id:
                    top_performers_query = top_performers_query.filter(Stream.id == combo.stream_id)
                else:
                    top_performers_query = top_performers_query.filter(Student.stream_id.is_(None))
                
                top_performers = top_performers_query.with_entities(
                    Student.id.label('student_id'),
                    Student.name.label('student_name'),
                    Student.admission_number.label('admission_number'),
                    Mark.mark.label('marks'),
                    Mark.total_marks.label('total_marks'),
                    func.round((Mark.mark * 100.0 / Mark.total_marks), 2).label('percentage')
                ).order_by(desc('percentage')).limit(3).all()
                
                print(f"✅ Top performers query works! Found {len(top_performers)} performers")
                for i, performer in enumerate(top_performers):
                    print(f"  {i+1}. {performer.student_name}: {performer.marks}/{performer.total_marks} ({performer.percentage}%)")
            
        except Exception as e:
            print(f"❌ Join logic failed: {str(e)}")
            import traceback
            traceback.print_exc()
        
        # Test report-based analytics
        print(f"\n=== TESTING REPORT-BASED ANALYTICS ===")
        try:
            from services.report_based_analytics_service import ReportBasedAnalyticsService
            
            available_reports = ReportBasedAnalyticsService.get_available_reports()
            print(f"Available cached reports: {len(available_reports)}")
            
            if available_reports:
                print("Sample reports:")
                for report in available_reports[:3]:
                    print(f"  - {report['type']}: {report['grade']} {report['stream']} - {report['term']} {report['assessment_type']}")
            else:
                print("No cached reports found - this is why analytics show 'no data'")
                print("Solution: Generate some reports first through the classteacher interface")
            
        except Exception as e:
            print(f"❌ Report-based analytics failed: {str(e)}")

if __name__ == '__main__':
    test_analytics_data()
