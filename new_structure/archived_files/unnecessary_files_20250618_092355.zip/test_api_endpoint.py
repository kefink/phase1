#!/usr/bin/env python3
"""
Test the enhanced top performers API endpoint
"""
import requests
import json
import time

def test_enhanced_top_performers_api():
    """Test the enhanced top performers API endpoint"""
    print("🧪 Testing Enhanced Top Performers API Endpoint...")
    
    # Wait a moment for server to start
    time.sleep(2)
    
    try:
        # Test the API endpoint
        url = "http://localhost:5000/api/analytics/enhanced-top-performers"
        params = {
            'limit': 5
        }
        
        print(f"📡 Making request to: {url}")
        print(f"📊 Parameters: {params}")
        
        response = requests.get(url, params=params, timeout=10)
        
        print(f"📈 Response status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Response received successfully")
            print(f"📊 Response keys: {list(data.keys())}")
            
            if data.get('success'):
                enhanced_data = data.get('enhanced_top_performers', {})
                total_grades = data.get('total_grades_analyzed', 0)
                
                print(f"🎯 Success: {data.get('success')}")
                print(f"📚 Total grades analyzed: {total_grades}")
                print(f"📊 Enhanced data keys: {list(enhanced_data.keys())}")
                
                if enhanced_data:
                    print("🏆 Top performers data found:")
                    for grade_name, streams in enhanced_data.items():
                        print(f"  📚 {grade_name}:")
                        for stream_name, performers in streams.items():
                            print(f"    🏫 {stream_name}: {len(performers)} performers")
                            if performers:
                                top = performers[0]
                                print(f"      🥇 Top: {top.get('name', 'N/A')} - {top.get('average_percentage', 0)}%")
                    return True
                else:
                    print("❌ No enhanced top performers data in response")
                    return False
            else:
                print(f"❌ API returned success=false: {data.get('message', 'No message')}")
                return False
        else:
            print(f"❌ HTTP Error {response.status_code}: {response.text}")
            return False
            
    except requests.exceptions.ConnectionError:
        print("❌ Connection error - is the Flask server running?")
        return False
    except Exception as e:
        print(f"💥 Exception: {e}")
        return False

if __name__ == "__main__":
    success = test_enhanced_top_performers_api()
    if success:
        print("\n🎉 API test PASSED!")
        print("The enhanced top performers endpoint is working correctly.")
    else:
        print("\n💔 API test FAILED!")
        print("Check the Flask server and endpoint implementation.")
