#!/usr/bin/env python3
"""
Test script to isolate startup issues
"""

import sys
import os

print("🔍 Testing application startup step by step...")

# Test 1: Basic imports
print("\n1. Testing basic imports...")
try:
    import flask
    print("✅ Flask imported successfully")
except Exception as e:
    print(f"❌ Flask import failed: {e}")
    sys.exit(1)

# Test 2: Test extensions import
print("\n2. Testing extensions import...")
try:
    from extensions import db, csrf
    print("✅ Extensions imported successfully")
except Exception as e:
    print(f"❌ Extensions import failed: {e}")

# Test 3: Test config import
print("\n3. Testing config import...")
try:
    from config import config
    print("✅ Config imported successfully")
except Exception as e:
    print(f"❌ Config import failed: {e}")

# Test 4: Test logging config
print("\n4. Testing logging config import...")
try:
    from logging_config import setup_logging
    print("✅ Logging config imported successfully")
except Exception as e:
    print(f"❌ Logging config import failed: {e}")

# Test 5: Test middleware import
print("\n5. Testing middleware import...")
try:
    from middleware import MarkSanitizerMiddleware
    print("✅ Middleware imported successfully")
except Exception as e:
    print(f"❌ Middleware import failed: {e}")

# Test 6: Test views import
print("\n6. Testing views import...")
try:
    from views import blueprints
    print(f"✅ Views imported successfully - {len(blueprints)} blueprints found")
except Exception as e:
    print(f"❌ Views import failed: {e}")

# Test 7: Test Flask app creation
print("\n7. Testing Flask app creation...")
try:
    from flask import Flask
    app = Flask(__name__)
    print("✅ Flask app created successfully")
except Exception as e:
    print(f"❌ Flask app creation failed: {e}")

# Test 8: Test config loading
print("\n8. Testing config loading...")
try:
    from config import config
    app.config.from_object(config['development'])
    print("✅ Config loaded successfully")
except Exception as e:
    print(f"❌ Config loading failed: {e}")

# Test 9: Test database initialization
print("\n9. Testing database initialization...")
try:
    from extensions import db
    db.init_app(app)
    print("✅ Database initialized successfully")
except Exception as e:
    print(f"❌ Database initialization failed: {e}")

# Test 10: Test CSRF initialization
print("\n10. Testing CSRF initialization...")
try:
    from extensions import csrf
    csrf.init_app(app)
    print("✅ CSRF initialized successfully")
except Exception as e:
    print(f"❌ CSRF initialization failed: {e}")

print("\n🎯 Startup test completed!")
print("If all tests passed, the issue might be with the security manager or blueprint registration.")
