#!/usr/bin/env python3
"""
Test MySQL connection and database status
"""

def test_mysql_connection():
    """Test MySQL connection with the configured credentials."""
    print("🔍 TESTING MYSQL CONNECTION")
    print("=" * 40)
    
    # MySQL connection details from config
    mysql_config = {
        'host': 'localhost',
        'port': 3306,
        'user': 'hillview_demo001_user',
        'password': 'hillview_demo_pass_2024',
        'database': 'hillview_demo001'
    }
    
    print(f"Host: {mysql_config['host']}")
    print(f"Port: {mysql_config['port']}")
    print(f"User: {mysql_config['user']}")
    print(f"Database: {mysql_config['database']}")
    print("-" * 40)
    
    try:
        import pymysql
        print("✅ PyMySQL module available")
        
        # Test connection
        connection = pymysql.connect(
            host=mysql_config['host'],
            port=mysql_config['port'],
            user=mysql_config['user'],
            password=mysql_config['password'],
            database=mysql_config['database']
        )
        
        print("✅ MySQL connection successful!")
        
        # Get MySQL version
        cursor = connection.cursor()
        cursor.execute("SELECT VERSION()")
        version = cursor.fetchone()
        print(f"📊 MySQL version: {version[0]}")
        
        # Check database
        cursor.execute("SELECT DATABASE()")
        current_db = cursor.fetchone()
        print(f"📁 Current database: {current_db[0]}")
        
        # List tables
        cursor.execute("SHOW TABLES")
        tables = cursor.fetchall()
        print(f"📋 Tables found: {len(tables)}")
        
        if tables:
            print("📄 Table list:")
            for table in tables:
                cursor.execute(f"SELECT COUNT(*) FROM {table[0]}")
                count = cursor.fetchone()[0]
                print(f"   - {table[0]} ({count:,} records)")
        else:
            print("⚠️ No tables found in database")
        
        connection.close()
        return True
        
    except ImportError:
        print("❌ PyMySQL module not available")
        print("   Install with: pip install pymysql")
        return False
        
    except Exception as e:
        print(f"❌ MySQL connection failed: {e}")
        print("\nPossible issues:")
        print("1. MySQL server is not running")
        print("2. Database 'hillview_demo001' doesn't exist")
        print("3. User 'hillview_demo001_user' doesn't exist or has wrong password")
        print("4. User doesn't have access to the database")
        return False

def check_sqlite_fallback():
    """Check if SQLite files exist as fallback."""
    print(f"\n🔍 CHECKING SQLITE FALLBACK")
    print("=" * 40)
    
    import os
    sqlite_files = []
    
    for file in os.listdir('.'):
        if file.endswith(('.db', '.sqlite', '.sqlite3')):
            size = os.path.getsize(file)
            sqlite_files.append((file, size))
    
    if sqlite_files:
        print("📄 Found SQLite database files:")
        for file, size in sqlite_files:
            print(f"   - {file} ({size:,} bytes)")
            
            # Test SQLite connection
            try:
                import sqlite3
                conn = sqlite3.connect(file)
                cursor = conn.cursor()
                
                # Check tables
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
                tables = cursor.fetchall()
                print(f"     Tables: {len(tables)}")
                
                # Check for key tables
                key_tables = ['teacher', 'student', 'subject', 'grade', 'stream']
                found_tables = [t[0] for t in tables]
                
                for key_table in key_tables:
                    if key_table in found_tables:
                        cursor.execute(f"SELECT COUNT(*) FROM {key_table}")
                        count = cursor.fetchone()[0]
                        print(f"     - {key_table}: {count} records")
                
                conn.close()
                
            except Exception as e:
                print(f"     Error reading SQLite file: {e}")
    else:
        print("📄 No SQLite database files found")
    
    return len(sqlite_files) > 0

def main():
    """Main function."""
    print("🏫 HILLVIEW DATABASE STATUS CHECK")
    print("=" * 50)
    
    # Test MySQL connection
    mysql_working = test_mysql_connection()
    
    # Check SQLite fallback
    sqlite_available = check_sqlite_fallback()
    
    # Summary and recommendations
    print(f"\n📊 SUMMARY & RECOMMENDATIONS")
    print("=" * 50)
    
    if mysql_working:
        print("✅ MySQL is working and configured correctly")
        print("🎯 Your system is using MySQL database as intended")
        
        if sqlite_available:
            print("ℹ️ SQLite files are present but not being used")
            print("💡 You can safely remove SQLite files if desired")
    
    elif sqlite_available:
        print("⚠️ MySQL is not working, but SQLite files are available")
        print("🔄 Options:")
        print("   1. Fix MySQL connection and migrate SQLite data to MySQL")
        print("   2. Temporarily switch to SQLite until MySQL is fixed")
        print("   3. Set up MySQL server and database")
    
    else:
        print("❌ Neither MySQL nor SQLite databases are available")
        print("🚨 Action required:")
        print("   1. Set up MySQL server and create database")
        print("   2. Or create SQLite database for development")
    
    print(f"\n🔧 CURRENT CONFIGURATION:")
    print("   Database Type: MySQL")
    print("   Host: localhost:3306")
    print("   Database: hillview_demo001")
    print("   User: hillview_demo001_user")

if __name__ == "__main__":
    main()
