#!/usr/bin/env python3
"""
Comprehensive Security Test Suite
Tests all implemented security protections against major web vulnerabilities.
"""

import requests
import json
import time

def test_application_security():
    """Test basic application security."""
    base_url = 'http://localhost:5000'
    
    print("🔒 COMPREHENSIVE SECURITY TEST SUITE")
    print("=" * 50)
    
    results = {
        'total_tests': 0,
        'passed_tests': 0,
        'failed_tests': 0
    }
    
    # Test 1: Check if application is running
    try:
        response = requests.get(base_url, timeout=5)
        if response.status_code == 200:
            print("✅ Application is accessible")
            results['passed_tests'] += 1
        else:
            print(f"❌ Application returned status {response.status_code}")
            results['failed_tests'] += 1
        results['total_tests'] += 1
    except Exception as e:
        print(f"❌ Cannot connect to application: {e}")
        results['failed_tests'] += 1
        results['total_tests'] += 1
        return results
    
    # Test 2: Check security headers
    try:
        response = requests.get(base_url)
        headers = response.headers
        
        security_headers = [
            'X-Content-Type-Options',
            'X-Frame-Options', 
            'X-XSS-Protection'
        ]
        
        for header in security_headers:
            if header in headers:
                print(f"✅ Security header present: {header}")
                results['passed_tests'] += 1
            else:
                print(f"❌ Security header missing: {header}")
                results['failed_tests'] += 1
            results['total_tests'] += 1
            
    except Exception as e:
        print(f"⚠️ Error testing security headers: {e}")
        results['failed_tests'] += 1
        results['total_tests'] += 1
    
    # Test 3: Test SQL injection protection (basic)
    try:
        sql_payload = "' OR '1'='1"
        response = requests.post(f"{base_url}/admin_login", data={
            'username': sql_payload,
            'password': 'test'
        })
        
        if response.status_code == 400 or 'error' in response.text.lower():
            print("✅ SQL injection protection active")
            results['passed_tests'] += 1
        else:
            print("❌ SQL injection protection may be missing")
            results['failed_tests'] += 1
        results['total_tests'] += 1
        
    except Exception as e:
        print(f"⚠️ Error testing SQL injection: {e}")
        results['failed_tests'] += 1
        results['total_tests'] += 1
    
    # Test 4: Test access control
    try:
        protected_endpoints = [
            '/headteacher/dashboard',
            '/headteacher/manage_teachers',
            '/admin/reports'
        ]
        
        for endpoint in protected_endpoints:
            response = requests.get(f"{base_url}{endpoint}")
            if response.status_code in [401, 403, 302]:  # 302 for redirect to login
                print(f"✅ Access control active for {endpoint}")
                results['passed_tests'] += 1
            else:
                print(f"❌ Unauthorized access possible to {endpoint}")
                results['failed_tests'] += 1
            results['total_tests'] += 1
            
    except Exception as e:
        print(f"⚠️ Error testing access control: {e}")
        results['failed_tests'] += 1
        results['total_tests'] += 1
    
    # Test 5: Test XSS protection (basic)
    try:
        xss_payload = "<script>alert('XSS')</script>"
        response = requests.get(f"{base_url}/", params={'search': xss_payload})
        
        if xss_payload not in response.text:
            print("✅ XSS protection active - payload sanitized")
            results['passed_tests'] += 1
        else:
            print("❌ XSS protection may be missing")
            results['failed_tests'] += 1
        results['total_tests'] += 1
        
    except Exception as e:
        print(f"⚠️ Error testing XSS protection: {e}")
        results['failed_tests'] += 1
        results['total_tests'] += 1
    
    # Calculate security score
    if results['total_tests'] > 0:
        security_score = (results['passed_tests'] / results['total_tests']) * 100
        print(f"\n🎯 SECURITY SCORE: {security_score:.1f}% ({results['passed_tests']}/{results['total_tests']})")
        
        if security_score >= 80:
            print("🛡️ GOOD SECURITY - System appears well protected")
        elif security_score >= 60:
            print("⚠️ MODERATE SECURITY - Some improvements needed")
        else:
            print("❌ POOR SECURITY - Significant security issues detected")
    
    return results

def main():
    """Main function to run security tests."""
    print("🚀 Starting Basic Security Test Suite...")
    print("⏳ Please ensure the application is running on http://localhost:5000")
    
    # Wait a moment for user to see the message
    time.sleep(2)
    
    results = test_application_security()
    
    print(f"\n📊 FINAL RESULTS:")
    print(f"Total Tests: {results['total_tests']}")
    print(f"Passed: {results['passed_tests']}")
    print(f"Failed: {results['failed_tests']}")

if __name__ == "__main__":
    main()
