#!/usr/bin/env python3
"""
Test script for teacher deletion functionality.
"""
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from .app import create_app
from .extensions import db
from .models.user import Teacher
from .utils.database_utils import safe_delete_teacher

def test_teacher_deletion():
    """Test the safe teacher deletion functionality."""
    app = create_app()
    
    with app.app_context():
        print("🧪 Testing Teacher Deletion Functionality")
        print("=" * 50)
        
        # Get all teachers
        teachers = Teacher.query.all()
        print(f"📊 Total teachers in database: {len(teachers)}")
        
        if not teachers:
            print("❌ No teachers found to test deletion")
            return
        
        # Find a teacher to test with (preferably not the main admin)
        test_teacher = None
        for teacher in teachers:
            if teacher.role != 'headteacher' and teacher.username != 'admin':
                test_teacher = teacher
                break
        
        if not test_teacher:
            print("⚠️ No suitable test teacher found (avoiding headteacher/admin)")
            # Create a test teacher
            test_teacher = Teacher(
                username='test_teacher_delete',
                password='test123',
                role='teacher'
            )
            db.session.add(test_teacher)
            db.session.commit()
            print(f"✅ Created test teacher: {test_teacher.username}")
        
        print(f"🎯 Testing deletion of teacher: {test_teacher.username} (ID: {test_teacher.id})")
        
        # Test the safe deletion
        result = safe_delete_teacher(test_teacher.id)
        
        print("\n📋 Deletion Result:")
        print(f"  Success: {result['success']}")
        print(f"  Message: {result['message']}")
        print(f"  Teacher Name: {result['teacher_name']}")
        
        if result['success']:
            # Verify teacher is actually deleted
            deleted_teacher = Teacher.query.get(test_teacher.id)
            if deleted_teacher is None:
                print("✅ Teacher successfully deleted from database")
            else:
                print("❌ Teacher still exists in database")
        else:
            print(f"❌ Deletion failed: {result['message']}")
        
        print("\n📊 Final teacher count:", len(Teacher.query.all()))

if __name__ == "__main__":
    test_teacher_deletion()
