#!/usr/bin/env python3
"""
Login Test with CSRF Token Support
Tests login functionality with proper CSRF token handling.
"""

import requests
import re
from bs4 import BeautifulSoup
from urllib.parse import urljoin

class CSRFLoginTester:
    def __init__(self, base_url="http://localhost:5000"):
        """Initialize the CSRF-aware login tester."""
        self.base_url = base_url
        self.session = requests.Session()
        
    def extract_csrf_token(self, html_content):
        """Extract CSRF token from HTML form."""
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            csrf_input = soup.find('input', {'name': 'csrf_token'})
            if csrf_input:
                return csrf_input.get('value')
            
            # Alternative: look for CSRF token in meta tag
            csrf_meta = soup.find('meta', {'name': 'csrf-token'})
            if csrf_meta:
                return csrf_meta.get('content')
            
            # Alternative: regex search
            csrf_match = re.search(r'name="csrf_token"[^>]*value="([^"]*)"', html_content)
            if csrf_match:
                return csrf_match.group(1)
                
            return None
        except Exception as e:
            print(f"Error extracting CSRF token: {e}")
            return None
    
    def test_headteacher_login_with_csrf(self):
        """Test headteacher login with proper CSRF token handling."""
        print("🔐 Testing Headteacher Login with CSRF Protection")
        print("=" * 50)
        
        try:
            # Step 1: Get login page and extract CSRF token
            login_url = urljoin(self.base_url, "/admin_login")
            print(f"📄 Accessing login page: {login_url}")
            
            response = self.session.get(login_url)
            if response.status_code != 200:
                print(f"❌ Cannot access login page: {response.status_code}")
                return False
            
            print("✅ Login page accessible")
            
            # Extract CSRF token
            csrf_token = self.extract_csrf_token(response.text)
            if not csrf_token:
                print("⚠️ No CSRF token found - trying login without it")
                csrf_token = ""
            else:
                print(f"✅ CSRF token extracted: {csrf_token[:20]}...")
            
            # Step 2: Prepare login data with CSRF token
            login_data = {
                'username': 'headteacher',
                'password': 'admin123'
            }
            
            if csrf_token:
                login_data['csrf_token'] = csrf_token
            
            print(f"🔑 Attempting login with credentials...")
            
            # Step 3: Submit login form
            response = self.session.post(login_url, data=login_data, allow_redirects=False)
            
            print(f"📊 Login response status: {response.status_code}")
            
            # Step 4: Check login result
            if response.status_code == 302:
                # Successful login - follow redirect
                redirect_url = response.headers.get('Location')
                print(f"✅ Login successful - redirecting to: {redirect_url}")
                
                if redirect_url:
                    if redirect_url.startswith('/'):
                        redirect_url = urljoin(self.base_url, redirect_url)
                    
                    dashboard_response = self.session.get(redirect_url)
                    if dashboard_response.status_code == 200:
                        print("✅ Dashboard accessible after login")
                        
                        # Check for headteacher-specific content
                        content = dashboard_response.text.lower()
                        headteacher_indicators = [
                            'headteacher',
                            'dashboard',
                            'admin',
                            'management',
                            'analytics'
                        ]
                        
                        found_indicators = [ind for ind in headteacher_indicators if ind in content]
                        if found_indicators:
                            print(f"✅ Headteacher dashboard confirmed: {', '.join(found_indicators)}")
                            return True
                        else:
                            print("⚠️ Dashboard accessible but content unclear")
                            return True
                    else:
                        print(f"❌ Dashboard not accessible: {dashboard_response.status_code}")
                        return False
                else:
                    print("❌ No redirect location provided")
                    return False
                    
            elif response.status_code == 200:
                # Login form returned - check for errors
                if 'invalid' in response.text.lower() or 'error' in response.text.lower():
                    print("❌ Login failed - invalid credentials")
                    return False
                else:
                    print("❌ Login form returned without redirect - possible validation error")
                    # Print some of the response for debugging
                    print(f"Response preview: {response.text[:500]}...")
                    return False
            else:
                print(f"❌ Unexpected response status: {response.status_code}")
                return False
                
        except Exception as e:
            print(f"❌ Login test failed with exception: {e}")
            return False
    
    def test_dashboard_functionality(self):
        """Test dashboard functionality after successful login."""
        print("\n🎯 Testing Dashboard Functionality")
        print("=" * 40)
        
        # First ensure we're logged in
        if not self.test_headteacher_login_with_csrf():
            print("❌ Cannot test dashboard - login failed")
            return False
        
        try:
            # Test dashboard access
            dashboard_url = urljoin(self.base_url, "/headteacher")
            response = self.session.get(dashboard_url)
            
            if response.status_code == 200:
                print("✅ Headteacher dashboard accessible")
                
                # Check for key dashboard elements
                content = response.text.lower()
                dashboard_elements = [
                    'total students',
                    'total teachers',
                    'analytics',
                    'management',
                    'reports'
                ]
                
                found_elements = [elem for elem in dashboard_elements if elem in content]
                print(f"✅ Dashboard elements found: {', '.join(found_elements)}")
                
                return len(found_elements) > 0
            else:
                print(f"❌ Dashboard not accessible: {response.status_code}")
                return False
                
        except Exception as e:
            print(f"❌ Dashboard test failed: {e}")
            return False
    
    def test_key_pages(self):
        """Test access to key headteacher pages."""
        print("\n📄 Testing Key Pages Access")
        print("=" * 40)
        
        # Ensure we're logged in first
        if not self.test_headteacher_login_with_csrf():
            print("❌ Cannot test pages - login failed")
            return False
        
        # Test key pages
        pages = [
            ("/headteacher", "Dashboard"),
            ("/headteacher/analytics", "Analytics"),
            ("/headteacher/manage_teachers", "Manage Teachers"),
            ("/headteacher/manage_students", "Manage Students"),
            ("/headteacher/reports", "Reports")
        ]
        
        accessible_pages = 0
        
        for url, name in pages:
            try:
                full_url = urljoin(self.base_url, url)
                response = self.session.get(full_url)
                
                if response.status_code == 200:
                    print(f"✅ {name}: Accessible")
                    accessible_pages += 1
                elif response.status_code == 302:
                    print(f"⚠️ {name}: Redirecting")
                elif response.status_code == 404:
                    print(f"⚠️ {name}: Not found (may not be implemented)")
                else:
                    print(f"❌ {name}: Error ({response.status_code})")
                    
            except Exception as e:
                print(f"❌ {name}: Exception - {e}")
        
        print(f"\n📊 Pages accessible: {accessible_pages}/{len(pages)}")
        return accessible_pages >= len(pages) * 0.6  # 60% success rate acceptable

def main():
    """Main testing function."""
    print("🧪 CSRF-AWARE LOGIN TESTING")
    print("Testing Hillview School Management System Login")
    print("=" * 60)
    
    tester = CSRFLoginTester()
    
    # Test basic connectivity first
    try:
        response = requests.get("http://localhost:5000", timeout=5)
        if response.status_code != 200:
            print(f"❌ Application not accessible: {response.status_code}")
            return False
        print("✅ Application is running and accessible")
    except Exception as e:
        print(f"❌ Cannot connect to application: {e}")
        print("Please ensure the application is running on localhost:5000")
        return False
    
    # Run tests
    tests = [
        ("Headteacher Login", tester.test_headteacher_login_with_csrf),
        ("Dashboard Functionality", tester.test_dashboard_functionality),
        ("Key Pages Access", tester.test_key_pages)
    ]
    
    results = {}
    
    for test_name, test_func in tests:
        try:
            print(f"\n🔍 Running: {test_name}")
            results[test_name] = test_func()
        except Exception as e:
            print(f"❌ {test_name} failed with exception: {e}")
            results[test_name] = False
    
    # Summary
    print("\n📋 FINAL TEST RESULTS")
    print("=" * 40)
    
    passed_tests = sum(1 for result in results.values() if result)
    total_tests = len(results)
    
    for test_name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{test_name:<25} {status}")
    
    success_rate = passed_tests / total_tests
    print(f"\nOverall Success Rate: {success_rate:.1%}")
    
    if success_rate >= 0.8:
        print("\n🎉 EXCELLENT: Login and core functionality working!")
        print("\n🚀 SYSTEM STATUS: READY FOR USE")
        print("\nLogin Credentials:")
        print("Username: headteacher")
        print("Password: admin123")
        print("URL: http://localhost:5000/admin_login")
    elif success_rate >= 0.6:
        print("\n✅ GOOD: Most functionality working with minor issues")
    else:
        print("\n❌ POOR: Significant issues need to be addressed")
    
    return success_rate >= 0.6

if __name__ == "__main__":
    success = main()
    if not success:
        exit(1)
