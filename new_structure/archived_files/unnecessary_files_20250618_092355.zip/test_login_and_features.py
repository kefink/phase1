#!/usr/bin/env python3
"""
Targeted Login and Feature Testing
Tests the actual login functionality and key features after MySQL migration.
"""

import requests
import time
from urllib.parse import urljoin

class LoginTester:
    def __init__(self, base_url="http://localhost:5000"):
        """Initialize the login tester."""
        self.base_url = base_url
        self.session = requests.Session()
        
    def test_headteacher_login_flow(self):
        """Test the complete headteacher login flow."""
        print("🔐 Testing Headteacher Login Flow")
        print("=" * 40)
        
        try:
            # Step 1: Access login page
            login_url = urljoin(self.base_url, "/admin_login")
            response = self.session.get(login_url)
            
            if response.status_code != 200:
                print(f"❌ Cannot access login page: {response.status_code}")
                return False
            
            print("✅ Login page accessible")
            
            # Step 2: Attempt login
            login_data = {
                'username': 'headteacher',
                'password': 'admin123'
            }
            
            response = self.session.post(login_url, data=login_data, allow_redirects=False)
            
            # Check for successful login (should redirect)
            if response.status_code == 302:
                print("✅ Login successful - redirecting")
                
                # Follow the redirect
                redirect_url = response.headers.get('Location')
                if redirect_url:
                    if redirect_url.startswith('/'):
                        redirect_url = urljoin(self.base_url, redirect_url)
                    
                    dashboard_response = self.session.get(redirect_url)
                    if dashboard_response.status_code == 200:
                        print("✅ Dashboard accessible after login")
                        return True
                    else:
                        print(f"❌ Dashboard not accessible: {dashboard_response.status_code}")
                        return False
                else:
                    print("❌ No redirect location provided")
                    return False
            else:
                print(f"❌ Login failed: {response.status_code}")
                if response.status_code == 200:
                    # Check if error message is present
                    if 'Invalid credentials' in response.text:
                        print("❌ Invalid credentials error")
                    else:
                        print("❌ Login form returned without redirect")
                return False
                
        except Exception as e:
            print(f"❌ Login test failed: {e}")
            return False
    
    def test_headteacher_pages(self):
        """Test headteacher pages after successful login."""
        print("\n🎯 Testing Headteacher Pages")
        print("=" * 40)
        
        # First ensure we're logged in
        if not self.test_headteacher_login_flow():
            print("❌ Cannot test pages - login failed")
            return False
        
        # Test key headteacher pages
        pages_to_test = [
            ("/headteacher", "Dashboard"),
            ("/headteacher/analytics", "Analytics"),
            ("/headteacher/manage_teachers", "Manage Teachers"),
        ]
        
        success_count = 0
        
        for url, name in pages_to_test:
            try:
                full_url = urljoin(self.base_url, url)
                response = self.session.get(full_url)
                
                if response.status_code == 200:
                    print(f"✅ {name}: Accessible")
                    success_count += 1
                elif response.status_code == 302:
                    print(f"⚠️ {name}: Redirecting (may need additional auth)")
                else:
                    print(f"❌ {name}: Failed ({response.status_code})")
                    
            except Exception as e:
                print(f"❌ {name}: Error - {e}")
        
        print(f"\n📊 Pages tested: {success_count}/{len(pages_to_test)} accessible")
        return success_count >= len(pages_to_test) * 0.8  # 80% success rate
    
    def test_database_connectivity(self):
        """Test database connectivity through web interface."""
        print("\n💾 Testing Database Connectivity")
        print("=" * 40)
        
        try:
            # Test a page that requires database access
            dashboard_url = urljoin(self.base_url, "/headteacher")
            response = self.session.get(dashboard_url)
            
            if response.status_code == 200:
                # Check for database-related content
                content = response.text.lower()
                
                # Look for signs of successful database queries
                database_indicators = [
                    'total students',
                    'total teachers', 
                    'dashboard',
                    'performance',
                    'analytics'
                ]
                
                found_indicators = [indicator for indicator in database_indicators if indicator in content]
                
                if found_indicators:
                    print(f"✅ Database connectivity confirmed")
                    print(f"   Found indicators: {', '.join(found_indicators)}")
                    return True
                else:
                    print("⚠️ Page loads but no database indicators found")
                    return False
            else:
                print(f"❌ Cannot access dashboard: {response.status_code}")
                return False
                
        except Exception as e:
            print(f"❌ Database connectivity test failed: {e}")
            return False
    
    def test_error_handling(self):
        """Test error handling and edge cases."""
        print("\n🧪 Testing Error Handling")
        print("=" * 40)
        
        try:
            # Test invalid login
            login_url = urljoin(self.base_url, "/admin_login")
            invalid_data = {
                'username': 'invalid_user',
                'password': 'wrong_password'
            }
            
            response = self.session.post(login_url, data=invalid_data)
            
            if response.status_code == 200 and 'Invalid credentials' in response.text:
                print("✅ Invalid login properly handled")
            else:
                print("⚠️ Invalid login handling unclear")
            
            # Test accessing protected page without login
            new_session = requests.Session()
            protected_url = urljoin(self.base_url, "/headteacher")
            response = new_session.get(protected_url, allow_redirects=False)
            
            if response.status_code == 302:
                print("✅ Protected pages properly redirect when not logged in")
            else:
                print("⚠️ Protected page access control unclear")
            
            return True
            
        except Exception as e:
            print(f"❌ Error handling test failed: {e}")
            return False

def main():
    """Main testing function."""
    print("🧪 TARGETED LOGIN AND FEATURE TESTING")
    print("Testing Hillview School Management System after MySQL Migration")
    print("=" * 70)
    
    tester = LoginTester()
    
    # Run tests
    tests = [
        ("Headteacher Login Flow", tester.test_headteacher_login_flow),
        ("Headteacher Pages", tester.test_headteacher_pages),
        ("Database Connectivity", tester.test_database_connectivity),
        ("Error Handling", tester.test_error_handling)
    ]
    
    results = {}
    
    for test_name, test_func in tests:
        try:
            print(f"\n🔍 Running: {test_name}")
            results[test_name] = test_func()
            time.sleep(1)  # Brief pause between tests
        except Exception as e:
            print(f"❌ {test_name} failed with exception: {e}")
            results[test_name] = False
    
    # Summary
    print("\n📋 TEST SUMMARY")
    print("=" * 40)
    
    passed_tests = sum(1 for result in results.values() if result)
    total_tests = len(results)
    
    for test_name, result in results.items():
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{test_name:<25} {status}")
    
    print(f"\nOverall: {passed_tests}/{total_tests} tests passed")
    success_rate = passed_tests / total_tests
    
    if success_rate >= 0.9:
        print("🎉 EXCELLENT: System is working very well!")
    elif success_rate >= 0.75:
        print("✅ GOOD: System is mostly functional")
    elif success_rate >= 0.5:
        print("⚠️ FAIR: System has some issues")
    else:
        print("❌ POOR: System needs attention")
    
    print(f"\n🎯 MYSQL MIGRATION STATUS: {'SUCCESS' if success_rate >= 0.75 else 'NEEDS REVIEW'}")
    
    if success_rate >= 0.75:
        print("\n🚀 READY FOR USE!")
        print("You can now:")
        print("1. Login as headteacher (username: headteacher, password: admin123)")
        print("2. Access all headteacher features")
        print("3. Manage teachers, students, and view analytics")
        print("4. Use the system for production")
    
    return success_rate >= 0.75

if __name__ == "__main__":
    success = main()
    if not success:
        exit(1)
