#!/usr/bin/env python3
"""
Script to find and fix relative import issues in view files
"""

import os
import re

def find_relative_imports(directory):
    """Find all files with relative imports."""
    relative_imports = []
    
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith('.py'):
                file_path = os.path.join(root, file)
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                        lines = content.split('\n')
                        
                        for i, line in enumerate(lines):
                            if re.search(r'from\s+\.\.', line):
                                relative_imports.append({
                                    'file': file_path,
                                    'line_num': i + 1,
                                    'line': line.strip()
                                })
                except Exception as e:
                    print(f"Error reading {file_path}: {e}")
    
    return relative_imports

def main():
    """Main function to find relative imports."""
    print("🔍 Finding relative imports in views directory...")
    
    views_dir = 'views'
    relative_imports = find_relative_imports(views_dir)
    
    if not relative_imports:
        print("✅ No relative imports found!")
        return
    
    print(f"❌ Found {len(relative_imports)} relative imports:")
    print("=" * 60)
    
    for imp in relative_imports:
        print(f"📁 File: {imp['file']}")
        print(f"📍 Line {imp['line_num']}: {imp['line']}")
        print("-" * 40)

if __name__ == "__main__":
    main()
