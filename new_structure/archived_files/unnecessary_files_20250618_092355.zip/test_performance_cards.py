#!/usr/bin/env python3
"""
Test to verify the performance card data structure and simulate the frontend display.
"""
import sqlite3
import json

def simulate_enhanced_top_performers():
    """Simulate the enhanced top performers data structure."""
    print("🧪 SIMULATING ENHANCED TOP PERFORMERS DATA")
    print("=" * 60)
    
    try:
        conn = sqlite3.connect('kirima_primary.db')
        cursor = conn.cursor()
        
        # Get enhanced top performers data (simulating the service)
        enhanced_performers = {}
        
        # Get all grades
        cursor.execute("SELECT id, name FROM grade ORDER BY name")
        grades = cursor.fetchall()
        
        for grade_id, grade_name in grades:
            enhanced_performers[grade_name] = {}
            
            # Get streams for this grade
            cursor.execute("SELECT id, name FROM stream WHERE grade_id = ? ORDER BY name", (grade_id,))
            streams = cursor.fetchall()
            
            for stream_id, stream_name in streams:
                # Get top performers for this grade/stream
                cursor.execute("""
                    SELECT 
                        s.id, s.name, s.admission_number,
                        AVG(m.percentage) as average_percentage,
                        COUNT(m.id) as total_assessments,
                        MIN(m.percentage) as min_percentage,
                        MAX(m.percentage) as max_percentage
                    FROM student s
                    JOIN mark m ON s.id = m.student_id
                    WHERE s.grade_id = ? AND s.stream_id = ?
                    GROUP BY s.id, s.name, s.admission_number
                    HAVING COUNT(m.id) >= 3
                    ORDER BY average_percentage DESC
                    LIMIT 5
                """, (grade_id, stream_id))
                
                performers = cursor.fetchall()
                
                if performers:
                    performers_with_details = []
                    
                    # Get total students in this class for position context
                    cursor.execute("""
                        SELECT COUNT(DISTINCT s.id) 
                        FROM student s 
                        WHERE s.grade_id = ? AND s.stream_id = ?
                    """, (grade_id, stream_id))
                    total_students_in_class = cursor.fetchone()[0]
                    
                    for index, performer in enumerate(performers):
                        student_id, name, admission_number, avg_pct, total_assessments, min_pct, max_pct = performer
                        
                        # Get subject marks for this student
                        cursor.execute("""
                            SELECT sub.name, m.percentage, m.raw_mark, 100 as total_marks, m.grade_letter
                            FROM mark m
                            JOIN subject sub ON m.subject_id = sub.id
                            WHERE m.student_id = ?
                            ORDER BY m.percentage DESC
                        """, (student_id,))
                        
                        subject_marks = cursor.fetchall()
                        
                        # Calculate total marks
                        total_raw_marks = sum(mark[2] for mark in subject_marks if mark[2])
                        total_max_marks = len(subject_marks) * 100  # Assuming 100 max per subject
                        
                        # Determine grade letter based on average
                        if avg_pct >= 90:
                            grade_letter = 'EE1'
                        elif avg_pct >= 75:
                            grade_letter = 'EE2'
                        elif avg_pct >= 58:
                            grade_letter = 'ME1'
                        elif avg_pct >= 41:
                            grade_letter = 'ME2'
                        elif avg_pct >= 31:
                            grade_letter = 'AE1'
                        elif avg_pct >= 21:
                            grade_letter = 'AE2'
                        elif avg_pct >= 11:
                            grade_letter = 'BE1'
                        else:
                            grade_letter = 'BE2'
                        
                        performer_data = {
                            'student_id': student_id,
                            'name': name,
                            'admission_number': admission_number,
                            'grade_name': grade_name,
                            'stream_name': stream_name,
                            'average_percentage': round(avg_pct, 2),
                            'total_assessments': total_assessments,
                            'min_percentage': round(min_pct, 2),
                            'max_percentage': round(max_pct, 2),
                            'grade_letter': grade_letter,
                            'total_raw_marks': int(total_raw_marks),
                            'total_max_marks': total_max_marks,
                            'class_position': index + 1,
                            'total_students_in_class': total_students_in_class,
                            'subject_marks': [
                                {
                                    'subject_name': mark[0],
                                    'percentage': round(mark[1], 2),
                                    'raw_mark': mark[2],
                                    'total_marks': mark[3],
                                    'grade_letter': mark[4]
                                }
                                for mark in subject_marks
                            ]
                        }
                        performers_with_details.append(performer_data)
                    
                    enhanced_performers[grade_name][stream_name] = performers_with_details
        
        conn.close()
        
        # Display the results in the format the frontend expects
        print("📊 ENHANCED TOP PERFORMERS DATA STRUCTURE:")
        print("=" * 60)
        
        for grade_name, streams in enhanced_performers.items():
            if streams:  # Only show grades with data
                print(f"\n🎓 {grade_name}:")
                
                for stream_name, performers in streams.items():
                    if performers:  # Only show streams with performers
                        print(f"\n  📚 Stream {stream_name} ({len(performers)} performers):")
                        
                        for i, performer in enumerate(performers, 1):
                            print(f"\n    {i}. {performer['name']} ({performer['admission_number']})")
                            print(f"       Position: #{performer['class_position']} of {performer['total_students_in_class']} students")
                            print(f"       Average: {performer['average_percentage']}% ({performer['grade_letter']})")
                            print(f"       Total Marks: {performer['total_raw_marks']}/{performer['total_max_marks']}")
                            print(f"       Range: {performer['min_percentage']}% - {performer['max_percentage']}%")
                            print(f"       Subjects: {len(performer['subject_marks'])}")
                            
                            # Show top 3 subjects
                            top_subjects = performer['subject_marks'][:3]
                            print(f"       Top Subjects: ", end="")
                            for j, subject in enumerate(top_subjects):
                                if j > 0:
                                    print(", ", end="")
                                print(f"{subject['subject_name']} ({subject['percentage']}%)", end="")
                            print()
        
        # Test the new performance card HTML structure
        print("\n" + "=" * 60)
        print("🎨 SIMULATED PERFORMANCE CARD HTML:")
        print("=" * 60)
        
        # Get one performer to simulate the card
        sample_performer = None
        for grade_name, streams in enhanced_performers.items():
            for stream_name, performers in streams.items():
                if performers:
                    sample_performer = performers[0]
                    break
            if sample_performer:
                break
        
        if sample_performer:
            total_marks_display = f"{sample_performer['total_raw_marks']}/{sample_performer['total_max_marks']}"
            
            print(f"""
<!-- Clean Performance Card -->
<div class="enhanced-performer-card rank-1" data-student-id="{sample_performer['student_id']}">
  <!-- Clean Header -->
  <div class="performer-card-header">
    <div class="performer-rank-badge">1</div>
    <div class="performer-basic-info">
      <div class="performer-name">{sample_performer['name']}</div>
      <div class="performer-admission">{sample_performer['admission_number']}</div>
    </div>
    <div class="performer-grade-badge">{sample_performer['grade_letter']}</div>
  </div>
  
  <!-- Position and Class Info -->
  <div class="performer-position">
    <div class="position-info">
      <span class="position-rank">#{sample_performer['class_position']}</span>
      <span class="position-text">of {sample_performer['total_students_in_class']} students</span>
    </div>
    <div class="percentage-display">{sample_performer['average_percentage']}%</div>
  </div>
  
  <!-- Summary Stats -->
  <div class="performer-summary">
    <div class="summary-item">
      <span class="summary-value">{total_marks_display}</span>
      <span class="summary-label">Total Marks</span>
    </div>
    <div class="summary-item">
      <span class="summary-value">{sample_performer['total_assessments']}</span>
      <span class="summary-label">Subjects</span>
    </div>
  </div>
  
  <!-- Toggle Button -->
  <button class="details-toggle" onclick="togglePerformerDetails('{sample_performer['student_id']}')">
    <i class="fas fa-chevron-down"></i>
    View Detailed Performance
  </button>
  
  <!-- Detailed Performance (Hidden by default) -->
  <div class="performer-details" id="details-{sample_performer['student_id']}">
    <div class="detailed-stats">
      <div class="detailed-stat">
        <span class="detailed-stat-value">{sample_performer['min_percentage']}%</span>
        <span class="detailed-stat-label">Lowest</span>
      </div>
      <div class="detailed-stat">
        <span class="detailed-stat-value">{sample_performer['average_percentage']}%</span>
        <span class="detailed-stat-label">Average</span>
      </div>
      <div class="detailed-stat">
        <span class="detailed-stat-value">{sample_performer['max_percentage']}%</span>
        <span class="detailed-stat-label">Highest</span>
      </div>
    </div>
    
    <div class="subject-performance-grid">""")
            
            # Show subject performance grid
            for subject in sample_performer['subject_marks'][:6]:  # Show first 6 subjects
                print(f"""      <div class="subject-item">
        <div class="subject-name-small">{subject['subject_name']}</div>
        <div class="subject-grade-small grade-{subject['grade_letter'].lower()}">{subject['grade_letter']}</div>
        <div class="subject-percentage-small">{subject['percentage']}%</div>
      </div>""")
            
            print("""    </div>
  </div>
</div>""")
        
        print("\n" + "=" * 60)
        print("✅ PERFORMANCE CARD SIMULATION COMPLETE!")
        print("🎯 Key improvements implemented:")
        print("   ✅ Total marks display (e.g., 742/900)")
        print("   ✅ Class position (#1 of 7 students)")
        print("   ✅ Clean, uncluttered design")
        print("   ✅ Toggle for detailed performance")
        print("   ✅ Compact subject grid")
        print("   ✅ Grade color coding")
        
        return True
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    simulate_enhanced_top_performers()
