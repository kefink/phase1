#!/usr/bin/env python3
"""
Test script to directly test the stream API endpoint.
"""

import requests
import json

def test_stream_api():
    """Test the stream API endpoint directly."""
    
    print("=== TESTING STREAM API ===")
    
    # Test different grade formats
    test_grades = ["1", "2", "8", "9"]
    
    base_url = "http://localhost:5000"
    
    for grade in test_grades:
        print(f"\n--- Testing Grade {grade} ---")
        
        # Test the API endpoint
        url = f"{base_url}/classteacher/get_streams_by_level/{grade}"
        print(f"URL: {url}")
        
        try:
            response = requests.get(url)
            print(f"Status Code: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                print(f"Response: {json.dumps(data, indent=2)}")
                
                if data.get('success'):
                    streams = data.get('streams', [])
                    print(f"✅ Found {len(streams)} streams")
                    for stream in streams:
                        print(f"   - Stream {stream['name']} (ID: {stream['id']})")
                else:
                    print(f"❌ API returned error: {data.get('message', 'Unknown error')}")
            else:
                print(f"❌ HTTP Error: {response.status_code}")
                print(f"Response: {response.text}")
                
        except requests.exceptions.ConnectionError:
            print("❌ Connection error - Flask app might not be running")
        except Exception as e:
            print(f"❌ Error: {e}")

if __name__ == "__main__":
    test_stream_api()
