#!/usr/bin/env python3
"""
Test Flask authentication directly by creating a minimal test route.
"""
import os
import sys

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_flask_auth():
    """Test Flask authentication in app context."""
    print("🌐 FLASK AUTHENTICATION TEST")
    print("=" * 50)
    
    try:
        # Import Flask components
        from flask import Flask
        from extensions import db
        from config import config
        from services.auth_service import authenticate_teacher
        from models.user import Teacher
        
        # Create a minimal Flask app
        app = Flask(__name__)
        app.config.from_object(config['development'])
        
        # Initialize database
        db.init_app(app)
        
        with app.app_context():
            print("✅ Flask app context created")
            
            # Test 1: Check if database is accessible
            try:
                teacher_count = Teacher.query.count()
                print(f"✅ Database accessible: {teacher_count} teachers found")
            except Exception as e:
                print(f"❌ Database error: {e}")
                return False
            
            # Test 2: Test authentication function directly
            print("\n🔐 Testing authentication function...")
            
            test_cases = [
                ('classteacher1', 'password123', 'classteacher'),
                ('headteacher', 'admin123', 'headteacher'),
                ('teacher1', 'teacher123', 'teacher'),
                ('invalid', 'invalid', 'classteacher')  # Should fail
            ]
            
            for username, password, role in test_cases:
                print(f"\n🧪 Testing: {username} / {password} / {role}")
                
                try:
                    teacher = authenticate_teacher(username, password, role)
                    
                    if teacher:
                        print(f"   ✅ SUCCESS: {teacher.username} (ID: {teacher.id})")
                    else:
                        print(f"   ❌ FAILED: No teacher returned")
                        
                        # Check if user exists with different credentials
                        user = Teacher.query.filter_by(username=username).first()
                        if user:
                            print(f"      User exists: {user.username} / {user.password} / {user.role}")
                            if user.password != password:
                                print(f"      Password mismatch!")
                            if user.role != role:
                                print(f"      Role mismatch!")
                        else:
                            print(f"      User '{username}' not found")
                            
                except Exception as e:
                    print(f"   ❌ ERROR: {e}")
                    import traceback
                    traceback.print_exc()
            
            # Test 3: Check if there are any database connection issues
            print("\n🔍 Database connection test...")
            try:
                # Try a simple query
                all_teachers = Teacher.query.all()
                print(f"✅ Found {len(all_teachers)} teachers:")
                for teacher in all_teachers:
                    print(f"   - {teacher.username} ({teacher.role})")
                    
                return True
                
            except Exception as e:
                print(f"❌ Database query error: {e}")
                return False
        
    except Exception as e:
        print(f"❌ Flask setup error: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_login_route():
    """Test the actual login route."""
    print("\n🌐 LOGIN ROUTE TEST")
    print("=" * 50)
    
    try:
        from flask import Flask
        from extensions import db, csrf
        from config import config
        from views.auth import auth_bp
        
        # Create Flask app
        app = Flask(__name__)
        app.config.from_object(config['development'])
        
        # Initialize extensions
        db.init_app(app)
        csrf.init_app(app)
        
        # Register blueprint
        app.register_blueprint(auth_bp)
        
        with app.test_client() as client:
            print("✅ Test client created")
            
            # Get login page
            response = client.get('/classteacher_login')
            print(f"✅ Login page: {response.status_code}")
            
            if response.status_code != 200:
                print(f"❌ Cannot access login page")
                return False
            
            # Extract CSRF token
            import re
            csrf_match = re.search(r'name="csrf_token" value="([^"]+)"', response.get_data(as_text=True))
            
            if not csrf_match:
                print("❌ No CSRF token found")
                return False
            
            csrf_token = csrf_match.group(1)
            print(f"✅ CSRF token extracted")
            
            # Submit login
            login_data = {
                'username': 'classteacher1',
                'password': 'password123',
                'csrf_token': csrf_token
            }
            
            post_response = client.post('/classteacher_login', data=login_data, follow_redirects=False)
            print(f"📥 Login response: {post_response.status_code}")
            
            if post_response.status_code == 302:
                redirect_url = post_response.headers.get('Location', '')
                print(f"✅ Redirected to: {redirect_url}")
                
                if 'classteacher' in redirect_url:
                    print("✅ Login successful!")
                    return True
                else:
                    print("❌ Unexpected redirect")
                    return False
            else:
                print(f"❌ Login failed: {post_response.status_code}")
                response_text = post_response.get_data(as_text=True)
                
                if 'Invalid credentials' in response_text:
                    print("   Error: Invalid credentials")
                else:
                    print("   No specific error found")
                    
                return False
        
    except Exception as e:
        print(f"❌ Login route test error: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run all tests."""
    print("🧪 FLASK AUTHENTICATION TESTS")
    print("=" * 60)
    
    # Test 1: Flask authentication
    auth_ok = test_flask_auth()
    
    # Test 2: Login route
    route_ok = test_login_route()
    
    print("\n📋 RESULTS")
    print("=" * 50)
    print(f"Flask Auth: {'✅ OK' if auth_ok else '❌ FAILED'}")
    print(f"Login Route: {'✅ OK' if route_ok else '❌ FAILED'}")
    
    if auth_ok and route_ok:
        print("\n🎯 AUTHENTICATION IS WORKING!")
        print("The issue is likely with the stream population API.")
    else:
        print("\n❌ AUTHENTICATION ISSUES FOUND")
        if not auth_ok:
            print("- Flask authentication function is broken")
        if not route_ok:
            print("- Login route is not working properly")

if __name__ == '__main__':
    main()
