#!/usr/bin/env python3
"""
Simple test for subject configuration API
"""

import sqlite3
import os

def test_database_direct():
    """Test the database directly."""
    
    db_path = 'kirima_primary.db'
    
    if not os.path.exists(db_path):
        print(f"❌ Database not found: {db_path}")
        return
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        print("🔍 Testing database access...")
        
        # Check if subject_configuration table exists
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='subject_configuration'")
        if cursor.fetchone():
            print("✅ subject_configuration table exists")
            
            # Get all configurations
            cursor.execute("SELECT * FROM subject_configuration")
            configs = cursor.fetchall()
            print(f"📊 Found {len(configs)} configurations")
            
            for config in configs:
                print(f"  - {config[1]} ({config[2]}): Composite={config[3]}")
        else:
            print("❌ subject_configuration table not found")
        
        # Check subjects
        cursor.execute("SELECT name, education_level, is_composite FROM subject WHERE LOWER(name) LIKE '%english%' OR LOWER(name) LIKE '%kiswahili%'")
        subjects = cursor.fetchall()
        print(f"\n📚 Found {len(subjects)} English/Kiswahili subjects:")
        for subject in subjects:
            print(f"  - {subject[0]} ({subject[1]}): Composite={subject[2]}")
        
        conn.close()
        
    except Exception as e:
        print(f"❌ Database error: {e}")

def test_toggle_update():
    """Test updating a configuration."""
    
    db_path = 'kirima_primary.db'
    
    if not os.path.exists(db_path):
        print(f"❌ Database not found: {db_path}")
        return
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        print("\n🔧 Testing configuration update...")
        
        # Test updating English for lower_primary
        subject_name = 'english'
        education_level = 'lower_primary'
        is_composite = True
        
        cursor.execute("""
            INSERT OR REPLACE INTO subject_configuration 
            (subject_name, education_level, is_composite, component_1_name, component_1_weight, 
             component_2_name, component_2_weight, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, datetime('now'))
        """, (subject_name, education_level, is_composite, 'Grammar', 60.0, 'Composition', 40.0))
        
        conn.commit()
        
        # Verify the update
        cursor.execute("""
            SELECT * FROM subject_configuration 
            WHERE subject_name = ? AND education_level = ?
        """, (subject_name, education_level))
        
        result = cursor.fetchone()
        if result:
            print(f"✅ Successfully updated {subject_name} ({education_level})")
            print(f"   Composite: {result[3]}, Components: {result[4]} ({result[5]}%), {result[6]} ({result[7]}%)")
        else:
            print(f"❌ Failed to update {subject_name} ({education_level})")
        
        conn.close()
        
    except Exception as e:
        print(f"❌ Update error: {e}")

if __name__ == "__main__":
    print("🧪 Testing Subject Configuration System...")
    test_database_direct()
    test_toggle_update()
    print("\n✅ Test completed!")
