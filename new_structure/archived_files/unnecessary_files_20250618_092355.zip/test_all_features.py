#!/usr/bin/env python3
"""
Comprehensive Feature Testing Script
Tests all application features to ensure no errors after MySQL migration.
"""

import requests
import json
import time
from datetime import datetime

class FeatureTester:
    def __init__(self, base_url="http://localhost:5000"):
        """Initialize the feature tester."""
        self.base_url = base_url
        self.session = requests.Session()
        self.test_results = {}
        
    def test_page_access(self, url, page_name, expected_status=200):
        """Test if a page is accessible."""
        try:
            response = self.session.get(f"{self.base_url}{url}")
            success = response.status_code == expected_status
            
            if success:
                print(f"✅ {page_name}: Accessible (Status: {response.status_code})")
            else:
                print(f"❌ {page_name}: Failed (Status: {response.status_code})")
                
            self.test_results[page_name] = {
                'success': success,
                'status_code': response.status_code,
                'url': url
            }
            
            return success, response
            
        except Exception as e:
            print(f"❌ {page_name}: Error - {e}")
            self.test_results[page_name] = {
                'success': False,
                'error': str(e),
                'url': url
            }
            return False, None
    
    def test_login(self, username, password, role, login_url="/admin_login"):
        """Test login functionality."""
        try:
            # Get login page first
            response = self.session.get(f"{self.base_url}{login_url}")
            if response.status_code != 200:
                print(f"❌ Login page not accessible: {response.status_code}")
                return False
            
            # Attempt login
            login_data = {
                'username': username,
                'password': password
            }
            
            response = self.session.post(f"{self.base_url}{login_url}", data=login_data)
            
            # Check if login was successful (usually redirects or shows dashboard)
            success = response.status_code in [200, 302] and 'error' not in response.text.lower()
            
            if success:
                print(f"✅ Login successful: {username} ({role})")
            else:
                print(f"❌ Login failed: {username} ({role}) - Status: {response.status_code}")
                
            return success
            
        except Exception as e:
            print(f"❌ Login error for {username}: {e}")
            return False
    
    def test_headteacher_features(self):
        """Test all headteacher features."""
        print("\n🎯 Testing Headteacher Features")
        print("=" * 50)
        
        # Test login
        login_success = self.test_login("headteacher", "admin123", "headteacher")
        if not login_success:
            print("❌ Cannot test headteacher features - login failed")
            return False
        
        # Test headteacher pages
        headteacher_pages = [
            ("/headteacher", "Headteacher Dashboard"),
            ("/headteacher/universal_access", "Universal Access"),
            ("/headteacher/staff_management", "Staff Management"),
            ("/headteacher/analytics", "Analytics Dashboard"),
            ("/headteacher/school_setup", "School Setup"),
            ("/headteacher/parent_management", "Parent Management"),
            ("/headteacher/reports", "Reports Management"),
            ("/headteacher/permissions", "Permissions Management")
        ]
        
        success_count = 0
        for url, name in headteacher_pages:
            success, _ = self.test_page_access(url, name)
            if success:
                success_count += 1
        
        print(f"\n📊 Headteacher Features: {success_count}/{len(headteacher_pages)} working")
        return success_count == len(headteacher_pages)
    
    def test_classteacher_features(self):
        """Test classteacher features."""
        print("\n👩‍🏫 Testing Classteacher Features")
        print("=" * 50)
        
        classteacher_pages = [
            ("/classteacher", "Classteacher Dashboard"),
            ("/classteacher/upload_marks", "Upload Marks"),
            ("/classteacher/generate_reports", "Generate Reports"),
            ("/classteacher/view_students", "View Students"),
            ("/classteacher/analytics", "Classteacher Analytics")
        ]
        
        success_count = 0
        for url, name in classteacher_pages:
            success, _ = self.test_page_access(url, name)
            if success:
                success_count += 1
        
        print(f"\n📊 Classteacher Features: {success_count}/{len(classteacher_pages)} working")
        return success_count == len(classteacher_pages)
    
    def test_parent_portal(self):
        """Test parent portal features."""
        print("\n👨‍👩‍👧‍👦 Testing Parent Portal")
        print("=" * 50)
        
        parent_pages = [
            ("/parent_login", "Parent Login Page"),
            ("/parent", "Parent Dashboard"),
            ("/parent/student_reports", "Student Reports"),
            ("/parent/profile", "Parent Profile")
        ]
        
        success_count = 0
        for url, name in parent_pages:
            success, _ = self.test_page_access(url, name)
            if success:
                success_count += 1
        
        print(f"\n📊 Parent Portal: {success_count}/{len(parent_pages)} working")
        return success_count == len(parent_pages)
    
    def test_api_endpoints(self):
        """Test API endpoints."""
        print("\n🔌 Testing API Endpoints")
        print("=" * 50)
        
        api_endpoints = [
            ("/api/grades", "Grades API"),
            ("/api/streams", "Streams API"),
            ("/api/subjects", "Subjects API"),
            ("/api/students", "Students API"),
            ("/api/teachers", "Teachers API")
        ]
        
        success_count = 0
        for url, name in api_endpoints:
            success, _ = self.test_page_access(url, name)
            if success:
                success_count += 1
        
        print(f"\n📊 API Endpoints: {success_count}/{len(api_endpoints)} working")
        return success_count == len(api_endpoints)
    
    def test_database_operations(self):
        """Test database operations through the web interface."""
        print("\n💾 Testing Database Operations")
        print("=" * 50)
        
        try:
            # Test data retrieval pages that show database content
            data_pages = [
                ("/headteacher/view_grades", "View Grades"),
                ("/headteacher/view_streams", "View Streams"),
                ("/headteacher/view_subjects", "View Subjects"),
                ("/headteacher/view_teachers", "View Teachers"),
                ("/headteacher/view_students", "View Students")
            ]
            
            success_count = 0
            for url, name in data_pages:
                success, response = self.test_page_access(url, name)
                if success and response:
                    # Check if page contains data or at least loads without errors
                    if "error" not in response.text.lower() and len(response.text) > 1000:
                        print(f"✅ {name}: Data loaded successfully")
                        success_count += 1
                    else:
                        print(f"⚠️ {name}: Page loads but may have issues")
            
            print(f"\n📊 Database Operations: {success_count}/{len(data_pages)} working")
            return success_count >= len(data_pages) * 0.8  # 80% success rate acceptable
            
        except Exception as e:
            print(f"❌ Database operations test failed: {e}")
            return False
    
    def test_static_resources(self):
        """Test static resources (CSS, JS, images)."""
        print("\n🎨 Testing Static Resources")
        print("=" * 50)
        
        static_resources = [
            ("/static/css/style.css", "Main CSS"),
            ("/static/js/main.js", "Main JavaScript"),
            ("/static/images/logo.png", "Logo Image")
        ]
        
        success_count = 0
        for url, name in static_resources:
            success, _ = self.test_page_access(url, name)
            if success:
                success_count += 1
        
        print(f"\n📊 Static Resources: {success_count}/{len(static_resources)} working")
        return success_count >= len(static_resources) * 0.7  # 70% acceptable for static resources
    
    def generate_test_report(self):
        """Generate comprehensive test report."""
        print("\n📋 COMPREHENSIVE TEST REPORT")
        print("=" * 60)
        
        total_tests = len(self.test_results)
        successful_tests = sum(1 for result in self.test_results.values() if result.get('success', False))
        
        print(f"📊 Overall Results: {successful_tests}/{total_tests} tests passed")
        print(f"📈 Success Rate: {(successful_tests/total_tests*100):.1f}%")
        
        print(f"\n✅ Successful Tests:")
        for name, result in self.test_results.items():
            if result.get('success', False):
                print(f"  - {name}")
        
        failed_tests = [name for name, result in self.test_results.items() if not result.get('success', False)]
        if failed_tests:
            print(f"\n❌ Failed Tests:")
            for name in failed_tests:
                result = self.test_results[name]
                error_info = result.get('error', f"Status: {result.get('status_code', 'Unknown')}")
                print(f"  - {name}: {error_info}")
        
        # Overall assessment
        if successful_tests >= total_tests * 0.9:
            print(f"\n🎉 EXCELLENT: System is working very well!")
        elif successful_tests >= total_tests * 0.8:
            print(f"\n✅ GOOD: System is mostly functional with minor issues")
        elif successful_tests >= total_tests * 0.6:
            print(f"\n⚠️ FAIR: System has some issues that need attention")
        else:
            print(f"\n❌ POOR: System has significant issues requiring immediate attention")
        
        return successful_tests / total_tests

def main():
    """Main testing function."""
    print("🧪 COMPREHENSIVE FEATURE TESTING")
    print("Testing Hillview School Management System after MySQL Migration")
    print("=" * 70)
    
    tester = FeatureTester()
    
    # Test basic connectivity
    print("🔗 Testing Basic Connectivity...")
    success, _ = tester.test_page_access("/", "Home Page")
    if not success:
        print("❌ Cannot connect to application. Please ensure it's running on localhost:5000")
        return False
    
    # Run all feature tests
    tests = [
        tester.test_headteacher_features,
        tester.test_classteacher_features,
        tester.test_parent_portal,
        tester.test_api_endpoints,
        tester.test_database_operations,
        tester.test_static_resources
    ]
    
    for test in tests:
        try:
            test()
            time.sleep(1)  # Brief pause between test suites
        except Exception as e:
            print(f"❌ Test suite failed: {e}")
    
    # Generate final report
    success_rate = tester.generate_test_report()
    
    print(f"\n🎯 TESTING COMPLETE")
    print(f"System is {'READY FOR USE' if success_rate >= 0.8 else 'NEEDS ATTENTION'}")
    
    return success_rate >= 0.8

if __name__ == "__main__":
    success = main()
    if not success:
        exit(1)
