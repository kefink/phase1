#!/usr/bin/env python3
"""
Simple test to verify the database has the expected data for analytics.
"""
import sqlite3
import os

def test_database_content():
    """Test database content for analytics readiness."""
    print("🧪 DATABASE CONTENT VERIFICATION")
    print("=" * 50)
    
    db_path = 'kirima_primary.db'
    if not os.path.exists(db_path):
        print("❌ Database file not found!")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        print("📊 Database Tables:")
        
        # Check table counts
        tables = [
            ('Students', 'student'),
            ('Marks', 'mark'),
            ('Grades', 'grade'),
            ('Streams', 'stream'),
            ('Subjects', 'subject'),
            ('Teachers', 'teacher'),
            ('Terms', 'term'),
            ('Assessment Types', 'assessment_type')
        ]
        
        for name, table in tables:
            cursor.execute(f"SELECT COUNT(*) FROM {table}")
            count = cursor.fetchone()[0]
            print(f"   {name:15}: {count:4d}")
        
        print("\n🏆 Sample Top Performers (by percentage):")
        cursor.execute("""
            SELECT s.name, sub.name as subject, m.percentage, m.grade_letter
            FROM mark m
            JOIN student s ON m.student_id = s.id
            JOIN subject sub ON m.subject_id = sub.id
            WHERE m.percentage >= 85
            ORDER BY m.percentage DESC
            LIMIT 10
        """)
        
        top_marks = cursor.fetchall()
        if top_marks:
            for i, (student, subject, percentage, grade) in enumerate(top_marks, 1):
                print(f"   {i:2d}. {student} - {subject}: {percentage}% ({grade})")
        else:
            print("   No high performers found (85%+)")
        
        print("\n📚 Subject Performance Summary:")
        cursor.execute("""
            SELECT sub.name, 
                   COUNT(m.id) as total_marks,
                   ROUND(AVG(m.percentage), 2) as avg_percentage,
                   MIN(m.percentage) as min_percentage,
                   MAX(m.percentage) as max_percentage
            FROM subject sub
            JOIN mark m ON sub.id = m.subject_id
            GROUP BY sub.id, sub.name
            ORDER BY avg_percentage DESC
        """)
        
        subject_stats = cursor.fetchall()
        if subject_stats:
            for subject, total, avg, min_pct, max_pct in subject_stats:
                print(f"   {subject:20}: {avg:5.1f}% avg ({total:3d} marks, {min_pct}-{max_pct}%)")
        else:
            print("   No subject performance data found")
        
        print("\n🏫 Class/Stream Performance:")
        cursor.execute("""
            SELECT g.name as grade, st.name as stream,
                   COUNT(DISTINCT s.id) as student_count,
                   COUNT(m.id) as total_marks,
                   ROUND(AVG(m.percentage), 2) as avg_percentage
            FROM grade g
            JOIN stream st ON g.id = st.grade_id
            LEFT JOIN student s ON st.id = s.stream_id
            LEFT JOIN mark m ON s.id = m.student_id
            GROUP BY g.id, st.id, g.name, st.name
            HAVING student_count > 0
            ORDER BY g.name, st.name
        """)
        
        class_stats = cursor.fetchall()
        if class_stats:
            for grade, stream, students, marks, avg in class_stats:
                avg_display = f"{avg:.1f}%" if avg else "No marks"
                print(f"   {grade} {stream:1}: {students:2d} students, {marks:3d} marks, {avg_display}")
        else:
            print("   No class performance data found")
        
        print("\n📈 Grade Distribution:")
        cursor.execute("""
            SELECT grade_letter, COUNT(*) as count
            FROM mark
            GROUP BY grade_letter
            ORDER BY grade_letter
        """)
        
        grade_dist = cursor.fetchall()
        if grade_dist:
            total_marks = sum(count for _, count in grade_dist)
            for grade, count in grade_dist:
                percentage = (count / total_marks) * 100
                print(f"   {grade:3}: {count:3d} marks ({percentage:4.1f}%)")
        else:
            print("   No grade distribution data found")
        
        print("\n👨‍🏫 Teacher Assignments:")
        cursor.execute("""
            SELECT t.username, t.role, 
                   CASE WHEN t.stream_id IS NOT NULL THEN 
                       (SELECT g.name || ' ' || st.name 
                        FROM stream st 
                        JOIN grade g ON st.grade_id = g.id 
                        WHERE st.id = t.stream_id)
                   ELSE 'No class assigned'
                   END as class_assignment
            FROM teacher t
            ORDER BY t.role, t.username
        """)
        
        teachers = cursor.fetchall()
        if teachers:
            for username, role, assignment in teachers:
                print(f"   {username:15} ({role:12}): {assignment}")
        else:
            print("   No teachers found")
        
        conn.close()
        
        # Verify we have sufficient data for analytics
        cursor = sqlite3.connect(db_path).cursor()
        cursor.execute("SELECT COUNT(*) FROM mark")
        mark_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(DISTINCT student_id) FROM mark")
        students_with_marks = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(DISTINCT subject_id) FROM mark")
        subjects_with_marks = cursor.fetchone()[0]
        
        print(f"\n✅ Analytics Readiness Check:")
        print(f"   Total marks: {mark_count}")
        print(f"   Students with marks: {students_with_marks}")
        print(f"   Subjects with marks: {subjects_with_marks}")
        
        if mark_count >= 100 and students_with_marks >= 10 and subjects_with_marks >= 5:
            print("✅ Database has sufficient data for comprehensive analytics!")
            return True
        else:
            print("⚠️  Database may have insufficient data for full analytics features")
            return False
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == '__main__':
    success = test_database_content()
    if success:
        print("\n🎯 Database is ready for analytics!")
        print("🌐 Next steps:")
        print("   1. Ensure Flask app is running (python run.py)")
        print("   2. Go to http://127.0.0.1:5000")
        print("   3. Click 'Admin Portal'")
        print("   4. Login: username=headteacher, password=admin123")
        print("   5. Navigate to Analytics Dashboard")
        print("   6. Explore the enhanced analytics features!")
    else:
        print("\n❌ Database needs more data for full analytics functionality.")
